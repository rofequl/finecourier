<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class our_inmormation extends Model
{
    //
}
