<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class zone_shipping_rate extends Model
{
    //
}
