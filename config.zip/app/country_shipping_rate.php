<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class country_shipping_rate extends Model
{
    //
}
