<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class zone_country_manage extends Model
{
    //
}
