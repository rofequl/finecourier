<?php $__env->startSection('content'); ?>

    <style>
        #previewImage {
            width: 100px;
            height: 100px;
            border: 1px dotted gray;
            text-align: center;
            cursor: pointer;
        }
    </style>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Country Shipping Rate</h3>
                </div>

                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">
                            Add New Country Rate
                        </button>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <?php if(isset($oneData)): ?>
                    <div class="x_panel">
                        <div class="x_content">
                            <form class="form-horizontal form-label-left" novalidate=""
                                  action="<?php echo e(route('AdminShippingRateUpdate')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input name="id" value="<?php echo e($oneData->id); ?>" type="hidden">
                                <span class="section">World Zone Rate Update</span>

                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12">From Cuntry</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="select2_single" name="from_country">
                                            <option value="">Choose option</option>
                                            <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($earths['code']== $oneData->from_country): ?>
                                                    <option value="<?php echo e($earths['code']); ?>" selected><?php echo e($earths['name']); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12">To Country</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="select2_single" name="to_country">
                                            <option value="">Choose option</option>
                                            <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($earths['code']== $oneData->to_country): ?>
                                                    <option value="<?php echo e($earths['code']); ?>" selected><?php echo e($earths['name']); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12">Price</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input type="number" class="form-control" name="price" placeholder="Price USD" value="<?php echo e($oneData->price); ?>">
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo e(route('SliderManage')); ?>" type="reset" class="btn btn-primary">
                                            Cancel
                                        </a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <table class="table table-bordered bulk_action">
                                <thead>
                                <tr class="bg-dark">
                                    <th>#</th>
                                    <th>From Country Name</th>
                                    <th>To Country Name</th>
                                    <th>Price</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <th scope="row"><?php echo e($datas->id); ?></th>
                                        <td><?php echo e(get_country_name_by_code($datas->from_country)->name); ?></td>
                                        <td><?php echo e(get_country_name_by_code($datas->to_country)->name); ?></td>
                                        <td><?php echo e($datas->price); ?> $</td>
                                        <td>
                                            <a href="<?php echo e(route('AdminShippingRate',$datas->id)); ?>" style="margin: 0 2px"
                                               data-toggle="tooltip" class="btn btn-success"
                                               data-placement="top" title=""
                                               data-original-title="Edit"><i
                                                        class="fa fa-edit"></i> Edit</a>
                                            <a href="<?php echo e(route('AdminShippingRateDelete','delete='.$datas->id)); ?>"
                                               style="margin: 0 2px" data-toggle="tooltip"
                                               data-placement="top" title=""
                                               data-original-title="Delete" class="btn btn-danger delete"><i
                                                        class="fa fa-trash"></i> Delete</a>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add World Zone Country</h4>
                </div>
                <form method="post" action="<?php echo e(route('AdminShippingRateAdd')); ?>">
                    <div class="modal-body">

                        <div class="form-horizontal form-label-left">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">From Cuntry</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select class="select2_single" name="from_country">
                                        <option value="">Choose option</option>
                                        <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">To Country</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select class="select2_single" name="to_country">
                                        <option value="">Choose option</option>
                                        <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12">Price</label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="number" class="form-control" name="price" placeholder="Price USD">
                                </div>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        $('.delete').click(function (e) {
            e.preventDefault(); // Prevent the href from redirecting directly
            var linkURL = $(this).attr("href");
            warnBeforeRedirect(linkURL);
        });

        function warnBeforeRedirect(linkURL) {
            swal({
                title: "Sure want to delete?",
                text: "If you click 'OK' file will be deleted",
                type: "warning",
                showCancelButton: true
            }, function () { // Redirect the user | linkURL is href url
                window.location.href = linkURL;
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/admin/quotation/shipping_rate.blade.php ENDPATH**/ ?>