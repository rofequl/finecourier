<div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
    <ul class="nav navbar-nav magic_menu">
        <li class="<?php echo e(Route::is('home') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('home')); ?>">home</a>
        </li>
        <li class="<?php echo e(Route::is('about_us') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('about_us')); ?>">About us</a>
        </li>
        <li class="<?php echo e(Route::is('service') ? 'active' : ''); ?> has_dropdown">
            <a href="<?php echo e(route('service')); ?>">services <span class="fa fa-angle-down"></span></a>
            <div class="dropdwon">
                <ul>
                    <?php $__currentLoopData = service(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="<?php echo e(route('SingleService',$services->id)); ?>"><?php echo e($services->title); ?></a></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>

        </li>
        
        
        
        
        
        

        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        <li class="<?php echo e(Route::is('news') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('news')); ?>">News</a>
            
            
            
            
            
            
        </li>
        <li class="<?php echo e(Route::is('contact') ? 'active' : ''); ?>"><a href="<?php echo e(route('contact')); ?>">contact</a></li>
        <li class="active"></li>
    </ul>
    <div class="search_form">
        <div class="search_btn" data-toggle="modal" data-target="#search_modal">
            <span class="fa fa-search"></span>
        </div>

        <!-- search Modal -->
        <div class="modal fade" id="search_modal" tabindex="-1" role="dialog">
            <div class="modal-dialog s_modal" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div class="search_form_wrapper">
                            <form method="post">
                                <div class="search_input">
                                    <input type="text" name="search_field" placeholder="Search Query...">
                                    <button class="submit_btn" type="submit">
                                        <span class="fa fa-search"></span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- END SEARCH MODAL -->
    </div>
    <ul class="lastnav pull-right">
        <?php if(Session::has('user-email')): ?>
            <li class="has_dropdown">
                <a href="#">My Account</a>
                <div class="dropdwon" style="width: 117px;">
                    <ul>
                        <li><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li><a href="<?php echo e(route('logout')); ?>">Logout</a></li>
                    </ul>
                </div>
            </li>
        <?php else: ?>
            <li>
                <a href="<?php echo e(route('login')); ?>" class="btn btn-default btn-sm" style="border-radius: 30px;margin-top: 13px;line-height: 39px">Log in</a>
            </li>
        <?php endif; ?>


    </ul>


</div><!-- /.navbar-collapse --><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/inc/menubar.blade.php ENDPATH**/ ?>