<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('inc.slide_area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--================================
    START LOGIN AREA
=================================-->
    <section class="login_area section_padding reveal animated" data-delay="0.2s" data-anim="fadeInUpShort">
        <!-- container starts -->
        <div class="container">
            <!-- row starts -->
            <div class="row">
                <div class="col-sm-4 col-md-3 sidebar">
                    <div class="mini-submenu">
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </div>
                    <div class="list-group">
                        <span href="#" class="list-group-item active">
                            Submenu
                            <span class="pull-right" id="slide-submenu">
                                <i class="fa fa-times"></i>
                            </span>
                        </span>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-comment-o"></i> Lorem ipsum
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-search"></i> Lorem ipsum
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-user"></i> Lorem ipsum
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-folder-open-o"></i> Lorem ipsum <span class="badge">14</span>
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-bar-chart-o"></i> Lorem ipsumr <span class="badge">14</span>
                        </a>
                        <a href="#" class="list-group-item">
                            <i class="fa fa-envelope"></i> Lorem ipsum
                        </a>
                    </div>
                </div>
                
            </div>
            </div><!-- /.row ends -->
        </div><!-- container ends -->
    </section>
    <!--================================
        END LOGIN AREA
    =================================-->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/dashboard.blade.php ENDPATH**/ ?>