<?php $__env->startSection('content'); ?>

        <div class="right_col" role="main">
            <div class="">
                <div class="page-title">
                    <div class="title_left">
                        <h3>Dashboard</h3>
                    </div>
                </div>

                <div class="clearfix"></div>
            </div>
        </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/admin/index.blade.php ENDPATH**/ ?>