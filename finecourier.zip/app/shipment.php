<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shipment extends Model
{
    //
}
