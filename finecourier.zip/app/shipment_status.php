<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class shipment_status extends Model
{
    //
}
