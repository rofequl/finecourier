<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class citie extends Model
{
    public $timestamps = false;
}
