<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class booking_shipment extends Model
{
    //
}
