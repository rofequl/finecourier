<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class domestic_price extends Model
{
    //
}
