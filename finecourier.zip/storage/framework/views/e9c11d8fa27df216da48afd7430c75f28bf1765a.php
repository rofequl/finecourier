<?php $__env->startSection('content'); ?>

    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="fa fa-user text-success">
                    </i>
                </div>
                <div>Hello <?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?>

                    <div class="page-title-subheading">You can update your profile here
                    </div>
                </div>
            </div>
            <div class="page-title-actions">
                <div class="d-inline-block dropdown">
                    <button type="button" onclick="location.href='<?php echo e(route('profile')); ?>';" class="btn-shadow btn btn-info">
                        <span class="btn-icon-wrapper pr-2 opacity-7"><i class="fa fa-hand-o-left" aria-hidden="true"></i></span>
                        Back Profile
                    </button>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
            <div class="main-card mb-3 card">
                <div class="card-body">
                    <form method="post" action="<?php echo e(route('ProfileUpdate')); ?>"  enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                        <div class="row justify-content-center mb-4">
                            <div class="col-md-3 col-12" onclick="chooseFile()" style="cursor: pointer">
                                <img src="<?php echo e($user->image==null? asset('images/user.png'):asset('storage/user/'.$user->image)); ?>" id="previewLogo" width="100%" class="border p-1">
                            </div>
                        </div>
                        <input type="file" name="image" class="ImageUpload d-none">
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="position-relative form-group"><label for="exampleEmail11" class="">First
                                        Name</label><input name="first_name" id="exampleEmail11"
                                                           value="<?php echo e($user->first_name); ?>" type="text"
                                                           class="form-control"></div>
                            </div>
                            <div class="col-md-6">
                                <div class="position-relative form-group"><label for="examplePassword11" class="">Last
                                        Name</label><input name="last_name" id="examplePassword11"
                                                           value="<?php echo e($user->last_name); ?>" type="text"
                                                           class="form-control"></div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="position-relative form-group"><label for="exampleEmail11"
                                                                                 class="">Phone</label><input
                                            name="phone" id="exampleEmail11" value="<?php echo e($user->phone); ?>" type="text"
                                            class="form-control"></div>
                            </div>
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="examplePassword11" class="">Country</label>
                                    <select class="form-control" id="CountryId" name="country">
                                        <option value="">Select Country</option>
                                        <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($earths['code'] == $user->country): ?>
                                                <option value="<?php echo e($earths['code']); ?>"
                                                        selected><?php echo e($earths['name']); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="col-md-6">
                                <div class="position-relative form-group">
                                    <label for="exampleCity" class="">City</label>
                                    <select class="form-control" id="FromState" name="division">
                                        <option value="">Select Country</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="position-relative form-group">
                                    <label for="exampleState" class="">State</label>
                                    <select class="form-control" id="FromCity" name="city">
                                        <option value="">Select Country</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="position-relative form-group"><label for="exampleZip" class="">Zip</label>
                                    <input name="post_code" id="exampleZip" value="<?php echo e($user->post_code); ?>" type="text" class="form-control">
                                </div>
                            </div>
                        </div>
                        <a href="<?php echo e(route('profile')); ?>" class="mt-2 btn btn-primary float-right mx-3">Cancel</a>
                        <button class="mt-2 btn btn-primary float-right">Save</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

    <script>
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        profileManage();
        function profileManage() {
            let country = $('#CountryId').val();
            let id = <?php echo e($user->division); ?>;
            $.ajax({
                url: "<?php echo e(route('SelectState')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: country},
                dataType: 'json',
                success: function (data) {
                    $('#FromState').html('');
                    data.forEach(function (element) {
                        $('#FromState').append($('<option>', {value: element.code, text: element.name}));
                        $('#FromState').val(id);
                    });
                }
            });

            $.ajax({
                url: "<?php echo e(route('SelectCity')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: id, country: country},
                dataType: 'json',
                success: function (data) {
                    $('#FromCity').html('');
                    data.forEach(function (element) {
                        $('#FromCity').append($('<option>', {value: element.code, text: element.name}));
                        $('#FromCity').val(<?php echo e($user->city); ?>);
                    });
                }
            });

        }

        $('#CountryId').change(function () {
            let id = $(this).val();
            $.ajax({
                url: "<?php echo e(route('SelectState')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: id},
                dataType: 'json',
                success: function (data) {
                    $('#FromState').html('');
                    data.forEach(function (element) {
                        $('#FromState').append($('<option>', {value: element.code, text: element.name}));
                    });
                }
            });
        });

        $('#FromState').change(function () {
            let country = $('#CountryId').val();
            let id = $(this).val();
            $.ajax({
                url: "<?php echo e(route('SelectCity')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: id, country: country},
                dataType: 'json',
                success: function (data) {
                    $('#FromCity').html('');
                    data.forEach(function (element) {
                        $('#FromCity').append($('<option>', {value: element.code, text: element.name}));
                    });
                }
            });
        });

        function chooseFile() {
            $(".ImageUpload").click();
        }

        $(function () {
            $(".ImageUpload").change(function () {
                let file = this.files[0];
                let imagefile = file.type;
                let match = ["image/jpeg", "image/png", "image/jpg"];
                if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
                    alert("only jpeg, jpg and png Images type allowed");
                    return false;
                } else {
                    $('#previewImage').html('<img src="" class="img-thumbnail h-100 mx-auto" id="previewLogo">');
                    let reader = new FileReader();
                    reader.onload = imageIsLoaded;
                    reader.readAsDataURL(this.files[0]);
                }
            });
        });

        function imageIsLoaded(e) {
            $('#previewLogo').attr('src', e.target.result);
        }



    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/dashboard/profile2.blade.php ENDPATH**/ ?>