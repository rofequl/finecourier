<?php $__env->startSection('pageTitle','Parcel Pickup'); ?>
<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Parcel Pickup</h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <form class="form-row" id="upload_form" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="input-group col-md-6">
                                    <input type="text" name="track" class="form-control"
                                           placeholder="Enter Tracking Code">
                                    <span class="input-group-btn">
                                              <button type="submit" class="btn btn-primary">
                                                  <i class="mdi mdi-account-search"></i>Search</button>
                                          </span>
                                </div>
                            </form>
                        </div>

                        <div class="x_content hidden product-info">
                            <div class="row">
                                <div class="col-md-4">
                                    <h4>Shipper</h4>
                                    <p>Name: <span class="shipper-name"></span></p>
                                    <p>phone: <span class="shipper-phone"></span></p>
                                    <p>Email: <span class="shipper-email"></span></p>
                                </div>
                                <div class="col-md-4">
                                    <h4>Receiver</h4>
                                    <p>Name: <span class="receiver-name"></span></p>
                                    <p>phone: <span class="receiver-phone"></span></p>
                                    <p>Email: <span class="receiver-email"></span></p>
                                </div>
                                <div class="col-md-4">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left w-100">
                                                    <div class="card card-body shadow-none p-1" id="FoundPrice"
                                                         style="text-align:center;border: 1px solid #ddd;font-size:15px;cursor: pointer;">
                                                        <div style="font-size: 20px;height: 79px;width: 83px;margin: 11px 0;border: 1px dotted blueviolet;border-radius: 50%;padding-top: 29px;display: inline-block;margin-left: auto;
                            margin-right: auto;" id="PriceShowing">

                                                        </div>
                                                        <h4>
                                                            <span id="NotFoundState1"></span>
                                                            <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                                            <span id="NotFoundState21"></span>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <p>Shipping content: <span class="shipping-type"></span></p>
                                    <p>Weight: <span class="weight"></span></p>
                                    <div class="checkbox pickup hidden" style="margin-left: 20px">
                                        <input type="checkbox" id="1" class="payment-input" value=""> Payment<br>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <p>Shipping type: <span class="shipment"></span></p>
                                    <p>Status: <span class="status"></span></p>
                                    <div class="checkbox pickup hidden" style="margin-left: 20px">
                                        <input type="checkbox" id="2" class="picked-input"  value=""> Picked?<br>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <p>Date: <span class="date"></span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.js')); ?>"></script>
    <script>
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        $(document).ready(function () {

            $('#upload_form').on('submit', function () {
                event.preventDefault();
                let form = new FormData(this);
                $.ajax({
                    url: "<?php echo e(route('AdminPickupGet')); ?>",
                    method: "POST",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form,
                    dataType: 'json',
                    error: function (data) {
                        if (data.status === 422) {
                            var errors = $.parseJSON(data.responseText);
                            let allData = '', mainData = '';
                            $.each(errors, function (key, value) {
                                if ($.isPlainObject(value)) {
                                    $.each(value, function (key, value) {
                                        allData += value + "<br/>";
                                    });
                                } else {
                                    mainData += value + "<br/>";
                                }
                            });
                            swal({
                                title: mainData,
                                text: allData,
                                type: 'error',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    },
                    success: function (data) {
                        if (data.done === 'shipment') {
                            $('.pickup').addClass('hidden');
                            $.ajax({
                                url: "<?php echo e(route('SelectAddress')); ?>",
                                type: 'post',
                                data: {_token: CSRF_TOKEN, id: data.data.shipper_address},
                                dataType: 'json',
                                success: function (datas) {
                                    $('.shipper-name').html(datas.name);
                                    $('.shipper-phone').html(datas.phone_one);
                                    $('.shipper-email').html(datas.email);
                                }
                            });
                            $.ajax({
                                url: "<?php echo e(route('SelectAddress')); ?>",
                                type: 'post',
                                data: {_token: CSRF_TOKEN, id: data.data.receiver_address},
                                dataType: 'json',
                                success: function (datas) {
                                    $('.receiver-name').html(datas.name);
                                    $('.receiver-phone').html(datas.phone_one);
                                    $('.receiver-email').html(datas.email);
                                }
                            });
                            $('.picked-input').val(data.data.id).attr('id',1);
                            $('.payment-input').val(data.data.id).attr('id',1);
                            $('.shipping-type').html(data.data.shipping_type);
                            $('.weight').html(data.data.weight + data.data.weight_type);
                            if (data.data.payment_status == 1){
                                $('.payment-input').prop('checked',true);
                            }else {
                                $('.payment-input').prop('checked',false);
                            }
                            if (data.data.shipment == 1){
                                $('.shipment').html('International');
                            }else {
                                $('.shipment').html('Domestic');
                            }
                            if (data.data.status == 1){
                                $('.status').html('Ready for pickup');
                                $('.pickup').removeClass('hidden');
                            }else if(data.data.status == 2){
                                $('.status').html('picked');
                                $('.pickup').removeClass('hidden');
                                $('.picked-input').prop('checked',true);
                            }else if(data.data.status == 3){
                                $('.status').html('Container');
                            }else if(data.data.status == 4){
                                $('.status').html('Shipped');
                            }else if(data.data.status == 5){
                                $('.status').html('Block');
                            }else if(data.data.status == 6){
                                $('.status').html('Cancel');
                            }else if(data.data.status == 7){
                                $('.status').html('Delivered');
                            }
                            $('.date').html(data.data.created_at);
                            $('#PriceShowing').html(data.data.price +' '+ data.data.currency);
                            $('#NotFoundState1').html(data.data.address_one);
                            $('#NotFoundState21').html(data.data.address_two);
                            $('.product-info').removeClass('hidden');


                        } else if (data.done === 'booking') {
                            $('.pickup').addClass('hidden');
                            $('.picked-input').val(data.data.id).attr('id',2);
                            $('.payment-input').val(data.data.id).attr('id',2);
                            $('.shipper-name').html(data.data.shipper_name);
                            $('.shipper-phone').html(data.data.shipper_phone);
                            $('.shipper-email').html(data.data.shipper_email);

                            $('.receiver-name').html(data.data.receiver_name);
                            $('.receiver-phone').html(data.data.receiver_phone);
                            $('.receiver-email').html(data.data.receiver_email);
                            if (data.data.payment_status == 1){
                                $('.payment-input').prop('checked',true);
                            }else {
                                $('.payment-input').prop('checked',false);
                            }
                            if (data.data.status == 1){
                                $('.status').html('Ready for pickup');
                                $('.pickup').removeClass('hidden');
                            }else if(data.data.status == 2){
                                $('.status').html('picked');
                                $('.pickup').removeClass('hidden');
                                $('.picked-input').prop('checked',true);
                            }else if(data.data.status == 3){
                                $('.status').html('Container');
                            }else if(data.data.status == 4){
                                $('.status').html('Shipped');
                            }else if(data.data.status == 5){
                                $('.status').html('Block');
                            }else if(data.data.status == 6){
                                $('.status').html('Cancel');
                            }else if(data.data.status == 7){
                                $('.status').html('Delivered');
                            }
                            $('.date').html(data.data.created_at);
                            $('#PriceShowing').html(data.data.price +' '+ data.data.currency);
                            $('#NotFoundState1').html(data.data.from_country);
                            if (data.data.to_country == null){
                                $('#NotFoundState21').html(data.data.from_country);
                            }else {
                                $('#NotFoundState21').html(data.data.to_country);
                            }
                            $('.shipping-type').html(data.data.shipping_type);
                            $('.weight').html(data.data.weight + data.data.weight_type);
                            if (data.data.booking_type == 1){
                                $('.shipment').html('International');
                            }else {
                                $('.shipment').html('Domestic');
                            }
                            $('.product-info').removeClass('hidden');


                        } else if (data.done === 'error') {
                            swal("Invalid number / data not currently available");
                            $('.product-info').addClass('hidden');
                        } else {
                            swal("Something wrong, please try again later!");
                            $("#upload_form").trigger("reset");
                            $('.product-info').addClass('hidden');
                        }
                    }
                })

            });

            jQuery('.picked-input').change(function() {
                if ($(this).prop('checked')) {
                    let id = $(this).attr('id'), action, value;
                    action = 'active';
                    value = $(this).val();
                    $.ajax({
                        url: '<?php echo e(route('AdminPickupStatus')); ?>',
                        type: 'post',
                        data: {_token: CSRF_TOKEN, id: id, action: action, value:value},
                        success: function (response) {
                            $('.status').html('Picked');
                        }
                    });
                }else {
                    let id = $(this).attr('id'), action, value;
                    action = 'inactive';
                    value = $(this).val();
                    $.ajax({
                        url: '<?php echo e(route('AdminPickupStatus')); ?>',
                        type: 'post',
                        data: {_token: CSRF_TOKEN, id: id, action: action, value:value},
                        success: function (response) {
                            $('.status').html('Ready for pickup');
                        }
                    });
                }
            });

            jQuery('.payment-input').change(function() {
                if ($(this).prop('checked')) {
                    let id = $(this).attr('id'), action, value;
                    action = 'active';
                    value = $(this).val();
                    $.ajax({
                        url: '<?php echo e(route('AdminPickupPaymentStatus')); ?>',
                        type: 'post',
                        data: {_token: CSRF_TOKEN, id: id, action: action, value:value},
                        success: function (response) {
                            $('.status').html('Picked');
                        }
                    });
                }else {
                    let id = $(this).attr('id'), action, value;
                    action = 'inactive';
                    value = $(this).val();
                    $.ajax({
                        url: '<?php echo e(route('AdminPickupPaymentStatus')); ?>',
                        type: 'post',
                        data: {_token: CSRF_TOKEN, id: id, action: action, value:value},
                        success: function (response) {
                            $('.status').html('Ready for pickup');
                        }
                    });
                }
            });

        });


    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/pickup.blade.php ENDPATH**/ ?>