<?php $__env->startSection('content'); ?>

    <style>
        .phonediv > div {
            display: block;
        }
    </style>

    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="fa fa-location-arrow text-success" aria-hidden="true"></i>
                </div>
                <div>Prepare Shipment
                    <div class="page-title-subheading">Fill in your details to prepare the shipment label
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
            <div class="main-card mb-3 card card-body">
                <form id="upload_form" method="post" action="">
                    <?php echo e(csrf_field()); ?>

                    <h5 class="card-title">Shipper Details: <span class="shipper_address_name"></span></h5>
                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="shipper_address" class="shipper_address_info"></label>
                                <select name="shipper_address" id="shipper_address" class="form-control my-select"
                                        data-live-search="true">
                                    <option value="" selected disabled>Select address</option>
                                    <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addresses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($addresses->id); ?>"><?php echo e($addresses->name); ?>

                                            (<?php echo e($addresses->post_code); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <h5 class="card-title">Receiver Details: <span class="receiver_address_name"></span></h5>
                    <div class="form-row">
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="receiver_address" class="receiver_address_info"></label>
                                <select name="receiver_address" id="receiver_address" class="form-control my-select"
                                        data-live-search="true">
                                    <option value="" selected disabled>Select address</option>
                                    <?php $__currentLoopData = $address; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $addresses): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($addresses->id); ?>"><?php echo e($addresses->name); ?>

                                            (<?php echo e($addresses->post_code); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <h5 class="card-title mt-4">Shipment Details:</h5>
                    <div class="form-row">
                        <div class="col-md-6 form-group text-left">
                            <label for="usr3">What are you planning to ship?</label>
                            <div class="row justify-content-center">
                                <div class="card card-body col-md-4 m-1 d-inline p-2"
                                     style="border: 1px solid #ddd;font-size:15px;cursor: pointer;"
                                     id="shipping_type1">
                                    <i class="fa fa-file-text" aria-hidden="true"></i>
                                    Document
                                </div>
                                <div class="card card-body col-md-4 m-1 d-inline p-2"
                                     style="border: 1px solid #ddd;font-size:15px;cursor: pointer;"
                                     id="shipping_type2">
                                    <i class="fa fa-cube" aria-hidden="true"></i>
                                    Parcel
                                </div>
                                <input type="hidden" value=""
                                       name="shipping_type" id="shipping_type">
                            </div>
                        </div>
                        <div class="col-md-6 form-group text-left">
                            <div class="row">
                                <div class="col-md-5">
                                    <label for="usr3">Number of peace:</label>
                                    <input type="text" name="peace" class="form-control" value="1">
                                </div>
                                <div class="col-md-7">
                                    <label for="weight">Weight:</label>
                                    <div class="input-group">
                                        <input type="text" name="weight" id="weight"
                                               class="form-control"
                                               value="0.5" required>
                                        <span class="input-group-addon"
                                              style="width:0px; padding-left:0px; padding-right:0px; border:none;"></span>
                                        <select id="weight_type" name="weight_type"
                                                class="form-control">
                                            <option value="KG">KG</option>
                                            <option value="LB">LB</option>
                                        </select>
                                        <div class="w-100">
                                            <small>My total chargeable weight is <span
                                                        class="weight_info">0.50 kg</span></small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-row my-4">
                        <div class="col text-left" id="parcel_content" style="display: none">
                            <label class="">Content of parcel*</label>
                            <input type="text" class="form-control" name="parcel_content">
                        </div>
                        <div class="col text-left">
                            <label class="">Goods origin*</label>
                            <select class="form-control select2" name="origin_country" id="origin_country">
                                <option value="" selected disabled>Select country</option>
                                <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col text-left">
                            <label for="usr3">Declared Value*</label>
                            <div class="input-group">
                                <input type="text" name="good_value"
                                       class="form-control"
                                       placeholder="0">
                                <span class="input-group-addon"
                                      style="width:0; padding-left:0; padding-right:0; border:none;"></span>
                                <select class="form-control" name="origin_currency" id="origin_currency"
                                        data-live-search="true">
                                    <option value="" selected disabled>Select currency</option>
                                    <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($earths['currency']); ?>"><?php echo e($earths['currency']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-row my-4">
                        <div class="col text-left">
                            <label class="">Shipment Reference</label>
                            <input type="text" class="form-control" name="shipment_reference">
                        </div>
                        <div class="col text-left">
                            <label class="">Remarks</label>
                            <textarea class="form-control" rows="3" name="remarks"></textarea>
                        </div>
                    </div>

                    <h5 class="card-title mt-5">Payment method:</h5>
                    <div class="form-row">
                        <div class="col-md-6 form-group text-left">
                            <label for="usr3">How do you want to arrange for payment?</label>
                            <div class="row justify-content-center">
                                <div class="card card-body col-md-4 m-1 p-3"
                                     style="border: 1px solid #ddd;font-size:15px;cursor: pointer;"
                                     id="delivery_type12">
                                    <h4 class="card-title">Regular</h4>
                                    <p class="mb-0" style="font-size: 12px;">I am exporting and I will pay when I
                                        ship</p>
                                </div>
                                <div class="card card-body col-md-4 m-1 p-3"
                                     style="border: 1px solid #ddd;font-size:15px;cursor: pointer;"
                                     id="delivery_type13">
                                    <h4 class="card-title">Express</h4>
                                    <p class="mb-0" style="font-size: 12px;">I am importing and I will pay when I</p>
                                </div>
                                <input type="hidden"
                                       value=""
                                       name="delivery_type" id="delivery_type11">
                            </div>
                        </div>
                        <div class="col-md-6 form-group text-left">
                            <label for="usr3">How do you want to payment?</label>
                            <div class="row justify-content-center">
                                <div class="card card-body col-md-4 m-1 p-3"
                                     style="border: 1px solid #ddd;font-size:15px;cursor: pointer;"
                                     id="delivery_type23">
                                    <p class="mb-0" style="font-size: 14px;">In cash by the shipper</p>
                                </div>
                                <div class="card card-body col-md-4 m-1 p-3"
                                     style="border: 1px solid #ddd;font-size:15px;cursor: pointer;"
                                     id="delivery_type24">
                                    <p class="mb-0" style="font-size: 14px;">By credit card by the shipper</p>
                                </div>
                                <input type="hidden"
                                       value=""
                                       name="payment_type" id="delivery_type22">
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="mt-2 px-4 btn btn-success float-right">Shipping Rate</button>

                    <div class="row justify-content-center">
                        <div class="col-md-6 col-sm-7">

                            <div class="card card-body d-none" id="FoundPrice"
                                 style="text-align:center;margin-top:80px;border: 1px solid #ddd;font-size:15px;cursor: pointer;">
                                <div style="font-size: 20px;height: 100px;width: 107px;margin: 20px 0;border: 1px dotted blueviolet;border-radius: 50%;padding-top: 35px;display: inline-block;margin-left: auto;
                            margin-right: auto;" id="PriceShowing">
                                </div>
                                <h4>
                                    <span id="NotFoundState1"></span>
                                    <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                    <span id="NotFoundState21"></span>
                                </h4>
                                <button type="button" id="submit_button" class="btn btn-success rounded my-4">
                                    Shipping Submit
                                </button>
                            </div>
                            <div class="card card-body d-none" id="NotFound"
                                 style="text-align:center;margin-top:80px;border: 1px solid #ddd;font-size:18px;cursor: pointer;">
                                <p>Cash Rates Are Not Yet Available</p>
                            </div>
                        </div>
                    </div>
                </form>
            </div>


        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/css/select2.min.css" rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/select2-bootstrap-theme/0.1.0-beta.10/select2-bootstrap.min.css"
          rel="stylesheet"/>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet"/>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.7/js/select2.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>

    <script>
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $('#shipper_address').change(function () {
            let id = $(this).val();
            $.ajax({
                url: "<?php echo e(route('SelectAddress')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: id},
                dataType: 'json',
                success: function (data) {
                    $('.shipper_address_name').text(data.name);
                    $('.shipper_address_info').text(data.name + ' from will be shipping this shipment from ' + data.address_one);
                }
            });
        });
        $('#receiver_address').change(function () {
            let id = $(this).val();
            $.ajax({
                url: "<?php echo e(route('SelectAddress')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: id},
                dataType: 'json',
                success: function (data) {
                    $('.receiver_address_name').text(data.name);
                    $('.receiver_address_info').text(data.name + ' from will be receving this shipment from ' + data.address_one);
                }
            });
        });
        $('#shipping_type1').click(function () {
            if ($('#shipping_type').val() === 'Parcel' || $('#shipping_type').val() === '') {
                $("#shipping_type").val('Document');
                $('#shipping_type1').css({'border': '1px solid red'});
                $('#shipping_type2').css({'border': '1px solid #ddd'});
                $('#parcel_content').hide('1000');
            }
        });
        $('#shipping_type2').click(function () {
            if ($('#shipping_type').val() === 'Document' || $('#shipping_type').val() === '') {
                $("#shipping_type").val('Parcel');
                $('#shipping_type2').css({'border': '1px solid red'});
                $('#shipping_type1').css({'border': '1px solid #ddd'});
                $('#parcel_content').show('1000');
            }
        });
        $('#weight').keyup(function () {
            let id = parseFloat($(this).val());
            $('.weight_info').text(id.toFixed(2) + ' ' + $('#weight_type').val());
        });
        $(document).ready(function () {
            $('.select2').select2({
                theme: "bootstrap",
                width: '100%'
            });
        });
        $('#origin_country').change(function () {
            let id = $(this).val();
            $.ajax({
                url: "<?php echo e(route('SelectCountryCode')); ?>",
                type: 'post',
                data: {_token: CSRF_TOKEN, id: id},
                dataType: 'json',
                success: function (data) {
                    $('#origin_currency').val(data.currency);
                }
            });
        });
        $('#delivery_type12').click(function () {
            if ($('#delivery_type11').val() === 'Express' || $('#delivery_type11').val() === '') {
                $("#delivery_type11").val('Regular');
                $('#delivery_type12').css({'border': '1px solid red'});
                $('#delivery_type13').css({'border': '1px solid #ddd'});
            }
        });
        $('#delivery_type13').click(function () {
            if ($('#delivery_type11').val() === 'Regular' || $('#delivery_type11').val() === '') {
                $("#delivery_type11").val('Express');
                $('#delivery_type13').css({'border': '1px solid red'});
                $('#delivery_type12').css({'border': '1px solid #ddd'});
            }
        });
        $('#delivery_type23').click(function () {
            if ($('#delivery_type22').val() == 1 || $('#delivery_type22').val() === '') {
                $("#delivery_type22").val(0);
                $('#delivery_type23').css({'border': '1px solid red'});
                $('#delivery_type24').css({'border': '1px solid #ddd'});
            }
        });
        $('#delivery_type24').click(function () {
            if ($('#delivery_type22').val() == 0 || $('#delivery_type22').val() === '') {
                $("#delivery_type22").val(1);
                $('#delivery_type24').css({'border': '1px solid red'});
                $('#delivery_type23').css({'border': '1px solid #ddd'});
            }
        });
        $(document).ready(function () {
            $('#upload_form').on('submit', function () {
                var form = new FormData(this);
                event.preventDefault();
                $.ajax({
                    url: "<?php echo e(route('PrepareShipmentAdd')); ?>",
                    type: 'post',
                    processData: false,
                    contentType: false,
                    data: form,
                    dataType: 'json',
                    error: function (data) {
                        if (data.status === 422) {
                            var errors = $.parseJSON(data.responseText);
                            let allData = '', mainData = '';
                            $.each(errors, function (key, value) {
                                if ($.isPlainObject(value)) {
                                    $.each(value, function (key, value) {
                                        allData += value + "<br/>";
                                    });
                                } else {
                                    mainData += value + "<br/>";
                                }
                            });
                            swal({
                                title: mainData,
                                text: allData,
                                type: 'error',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    },
                    success: function (data) {
                        if (data.error == 'error') {
                            if (!$('#FoundPrice').hasClass('d-none')) {
                                $('#FoundPrice').addClass('d-none');
                            }
                            $('#NotFound').removeClass('d-none');
                            $('html, body').animate({
                                scrollTop: $("#NotFound").offset().top - 350
                            }, 2000);
                        } else {
                            if (!$('#NotFound').hasClass('d-none')) {
                                $('#NotFound').addClass('d-none');
                            }
                            $('#FoundPrice').removeClass('d-none');
                            $('#NotFoundState1').html(data.shipper_address);
                            $('#NotFoundState21').html(data.receiver_address);
                            $('#PriceShowing').html(data.price + ' ' + data.currency);
                            $('html, body').animate({
                                scrollTop: $("#FoundPrice").offset().top - 350
                            }, 2000);
                        }
                    }
                });
            });
            $('#submit_button').click(function () {
                var form = new FormData($('#upload_form')[0]);
                warnBeforeRedirect(form);
            });
            function warnBeforeRedirect(form) {
                swal({
                        title: "Sure want to save?",
                        text: "If you click 'OK' you cant edit data.",
                        type: "warning",
                        showCancelButton: true
                    }, function () {
                        $.ajax({
                            url: "<?php echo e(route('PrepareShipmentSubmit')); ?>",
                            type: 'post',
                            processData: false,
                            contentType: false,
                            data: form,
                            dataType: 'json',
                            success: function (data) {
                                if (data.error == 'error') {
                                    swal({
                                        title: "Something wrong",
                                        text: 'Please check the shipping rate again.',
                                        type: 'error',
                                        confirmButtonText: 'Ok'
                                    })
                                } else {
                                    var url = '<?php echo e(route("PrepareShipmentEdit", ":slug")); ?>';

                                    url = url.replace(':slug', data.id);

                                    window.location.href=url;
                                }
                            }
                        });
                    }
                );
            }
        });
    </script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/dashboard/shipment.blade.php ENDPATH**/ ?>