<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('inc.slide_area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--================================
        START ABOUT US AREA
    =================================-->
    <section class="about_us_area dark_bg section_padding reveal animated" data-delay="0.2s" data-anim="fadeInUpShort">
        <!-- container starts -->
        <div class="container">

            <!-- row starts -->
            <div class="row">
                <!-- /.col-md-6 starts -->
                <div class="col-md-6 xs_fullwidth col-xs-6">
                    <!-- section_title starts -->
                    <div class="section_title">
                        <div class="sub_title">
                            <p>Ask Question</p>
                        </div>
                        <div class="title"><h2>faq</h2></div>
                    </div><!-- section_title starts -->

                    <!-- accrodion area starts  -->
                    <div class="accordion_wrapper">
                        <!-- panel-group start -->
                        <div class="panel-group" id="accordion">

                            <!-- single accprdion pnae start -->
                            <?php $__currentLoopData = $faq; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="panel panel-default">
                                    <div class="single_acco_title">
                                        <h4 class="panel-title">
                                            <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo e($faqs->id); ?>"
                                               aria-expanded="false" class="collapsed">
                                                <?php echo e($faqs->message); ?>

                                                <span class="fa fa-plus"></span></a>
                                        </h4>
                                    </div>
                                    <div id="<?php echo e($faqs->id); ?>" class="panel-collapse collapse" aria-expanded="false"
                                         style="height: 0px;" role="tablist">
                                        <div class="panel-body text-justify"><p><?php echo e($faqs->description); ?></p>
                                            <span class="acoo_icon fa fa-truck"></span>
                                        </div>
                                    </div>
                                </div><!-- single accprdion pnae end -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div><!-- /.panel-group ends -->
                    </div><!-- accrodion area ends  -->
                </div><!-- /.col-md-6 ends -->

                <!-- /.col-md-6 starts -->
                <div class="col-md-6 xs_fullwidth col-xs-6">
                    <div class="right_message">
                        <!-- section_title starts -->
                        <div class="section_title">
                            <div class="sub_title">
                                <p>Contact Us</p>
                            </div>
                            <div class="title"><h2>send us message</h2></div>
                        </div><!-- section_title starts -->
                        <?php if($errors->any()): ?>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="alert alert-danger alert-dismissible">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e($error); ?>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        <?php if(session()->has('message')): ?>
                            <div class="alert alert-danger alert-dismissible">
                                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                <?php echo e(session()->get('message')); ?>

                            </div>
                    <?php endif; ?>
                    <!-- send us message form -->
                        <div class="send_message">
                            <form action="<?php echo e(route('AddFaq')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>

                                <div class="form_half">
                                    <input class="name" type="text" placeholder="Name" name="name">
                                </div>
                                <div class="form_half">
                                    <input class="phone" type="text" placeholder="Phon No" name="phone">
                                </div>
                                <input type="email" placeholder="Your Email" name="email">

                                <textarea name="message" placeholder="Write Your Text" id="message" cols="30"
                                          rows="10"></textarea>

                                <div class="submit_btn">
                                    <button class="trust_btn" type="submit" name="button">send message</button>
                                </div>
                            </form>
                        </div>
                        <!-- end send us message form -->
                    </div>
                </div><!-- /.col-md-6 ends -->
            </div><!-- /.row ends -->

        </div><!-- /.container ends -->
    </section>
    <!--================================
        END ABOUT US AREA
    =================================-->

    <!--================================
        START PARTNER
    =================================-->
    <section class="partner_area section_padding reveal animated" data-delay="0.2s" data-anim="fadeInUpShort">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <!-- section_title starts -->
                    <div class="section_title title_center">
                        <div class="sub_title">
                            <p>What Our Partner Was</p>
                        </div>
                        <div class="title"><h2>Sponsor</h2></div>
                    </div><!-- section_title starts -->
                </div>
            </div><!-- /.row end -->
            <div class="row">
                <div class="col-md-12">
                    <div class="partner_wrapper">
                        <div class="partner_slider">
                            <?php $__currentLoopData = $sponsor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sponsors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="partner">
                                    <a href="<?php echo e($sponsors->url); ?>"><img
                                                src="<?php echo e(asset('storage/sponsor/'.$sponsors->image)); ?>" alt=""
                                                height="100%"></a>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--================================
        END PARTNER
    =================================-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/faq.blade.php ENDPATH**/ ?>