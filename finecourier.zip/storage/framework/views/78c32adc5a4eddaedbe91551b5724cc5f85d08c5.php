<?php $__env->startSection('content'); ?>

    <style>
        .card-title{
            font-family: -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,"Noto Sans",sans-serif,"Apple Color Emoji","Segoe UI Emoji","Segoe UI Symbol","Noto Color Emoji";
        }
    </style>


    <div class="app-page-title">
        <div class="page-title-wrapper">
            <div class="page-title-heading">
                <div class="page-title-icon">
                    <i class="fa fa-cog text-success">
                    </i>
                </div>
                <div><?php echo e($user->first_name); ?> <?php echo e($user->last_name); ?> Account Setting
                    <div class="page-title-subheading">You can change email and password here
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="tab-content">
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <?php if(session()->has('message')): ?>
            <div class="alert alert-success alert-dismissible">
                <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                <?php echo e(session()->get('message')); ?>

            </div>
        <?php endif; ?>
        <div class="tab-pane tabs-animation fade show active" id="tab-content-0" role="tabpanel">
            <div class="row">
                <div class="col-md-6">
                    <div class="main-card mb-3 card">
                        <div class="card-body"><h5 class="card-title">Change your email address</h5>
                            <form class="" autocomplete="off" method="post" action="<?php echo e(route('ChangeMail')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                <div class="position-relative form-group"><input
                                        id="exampleEmail" value="<?php echo e($user->email); ?>" type="email"
                                        class="form-control" readonly></div>
                                <div class="position-relative form-group"><input
                                        name="email" autocomplete="off" id="exampleEmail" placeholder="Enter your new email address" type="email"
                                        class="form-control" required></div>
                                <div class="position-relative form-group"><input
                                        name="password" id="examplePassword" placeholder="Enter your password"
                                        type="password" class="form-control" required></div>
                                <button class="mt-1 btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="main-card mb-3 card">
                        <div class="card-body"><h5 class="card-title">Change your password</h5>
                            <form method="post" action="<?php echo e(route('ChangePassword')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($user->id); ?>">
                                <div class="position-relative form-group"><input
                                        name="old_password" id="examplePassword" placeholder="Enter your old password"
                                        type="password" class="form-control"></div>
                                <div class="position-relative form-group"><input
                                        name="password" id="examplePassword" placeholder="Enter your new password"
                                        type="password" class="form-control"></div>
                                <div class="position-relative form-group"><input
                                        name="password_confirmation" id="examplePassword" placeholder="Confirm your password"
                                        type="password" class="form-control"></div>
                                <button class="mt-1 btn btn-primary">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>



<?php $__env->stopPush(); ?>

<?php echo $__env->make('dashboard.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/dashboard/account.blade.php ENDPATH**/ ?>