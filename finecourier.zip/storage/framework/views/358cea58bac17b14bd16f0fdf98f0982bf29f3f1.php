<?php $__env->startSection('pageTitle','Shipping List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>All prepare shipping information</h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <div class="btn-group btn-group-justified">
                                <div class="btn-group">
                                    <button type="button"
                                            onclick="location.href='<?php echo e(route('AdminShipment','type='.base64_encode(1))); ?>';"
                                            id="international" class="btn <?php echo e($change==1?'btn-primary':'btn-default'); ?> ">
                                        International
                                    </button>
                                </div>
                                <div class="btn-group">
                                    <button type="button"
                                            onclick="location.href='<?php echo e(route('AdminShipment','type='.base64_encode(2))); ?>';"
                                            id="domestic" class="btn <?php echo e($change==2?'btn-primary':'btn-default'); ?>">
                                        Domestic
                                    </button>
                                </div>
                            </div>
                            <p style="margin-top: 10px">Simple table with shipping request any people</p>

                            <!-- start project list -->
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered projects">
                                    <thead>
                                    <tr>
                                        <th class="text-center" style="width: 1%">#</th>
                                        <th class="text-center">Tracking Code</th>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">Name</th>
                                        <th class="text-center">From</th>
                                        <th class="text-center">To</th>
                                        <th class="text-center">Shipping content</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $no=1; ?>
                                    <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td><?php echo e($no); ?></td>
                                            <?php $no++; ?>
                                            <td class="text-left">
                                                <?php echo DNS1D::getBarcodeHTML($shipment->tracking_code, "EAN13",1,23); ?>

                                                <p style="font-size: 15px;color: black;">
                                                    *<?php echo e($shipment->tracking_code); ?>*</p>
                                            </td>
                                            <td>
                                                <?php echo e($shipment->created_at->format('d M, Y')); ?>

                                            </td>
                                            <td>
                                                <a title="Header" data-toggle="popover" data-trigger="hover"
                                                   data-content="Some content">
                                                    <?php echo e(get_user_by_id($shipment->user_id)->first_name); ?>

                                                    <?php echo e(get_user_by_id($shipment->user_id)->last_name); ?>

                                                </a>
                                            </td>
                                            <td>
                                                <?php echo e($shipment->address_one); ?>

                                            </td>
                                            <td>
                                                <?php echo e($shipment->address_two); ?>

                                            </td>
                                            <td>
                                                <?php echo e($shipment->shipping_type); ?>

                                            </td>
                                            <td>

                                                <?php if($shipment->block == 1): ?>
                                                    <span class="label label-danger">Reject</span>
                                                <?php else: ?>
                                                    <span class="label label-success">
                                                    <?php echo e($shipment->status==1?'Confirm Shipment':''); ?>

                                                        <?php echo e($shipment->status==2?'Picked':''); ?>

                                                        <?php echo e($shipment->status==3?'Container':''); ?>

                                                        <?php echo e($shipment->status==4?'Shipped':''); ?>

                                                        <?php echo e($shipment->status==5?'Delivered':''); ?>

                                                        <?php echo e($shipment->status==6?'Block':''); ?>

                                                </span><br>
                                                    <?php if($shipment->status != 1): ?>
                                                        <?php echo e(get_shipment_status($shipment->tracking_code, $shipment->status)->time); ?>

                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('AdminShipmentView','data='.base64_encode($shipment->id))); ?>"
                                                   class="btn btn-success"><i class="mdi mdi-teamviewer"
                                                                              style="margin-right: 4px;"></i>View</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php echo $shipping->render(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/shipment/shipment.blade.php ENDPATH**/ ?>