<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Content-Language" content="en">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <title><?php echo $__env->yieldContent('pageTitle'); ?> - Fine Courier</title>
    <meta name="viewport"
          content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no"/>
    <link href="https://fonts.googleapis.com/css?family=Lato&display=swap" rel="stylesheet">
    <meta name="description" content="This is an example dashboard created using build-in elements and components.">
    <meta name="msapplication-tap-highlight" content="no">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <link href="<?php echo e(asset('assets/scripts/main.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>"/>
    <?php echo $__env->yieldPushContent('style'); ?>
</head>
<body style="font-family: 'Lato', serif;">


<div class="app-container app-theme-white body-tabs-shadow fixed-sidebar fixed-header">
    <?php echo $__env->make('dashboard.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="app-main">
        <?php echo $__env->make('dashboard.inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="app-main__outer">
            <div class="app-main__inner">
                <?php echo $__env->yieldContent('content'); ?>

            </div>
            <div class="app-wrapper-footer">
                <div class="app-footer">
                    <div class="app-footer__inner">
                        <div class="app-footer-right">
                              <p>
                                  <?php echo e(basic_information()->footer_text); ?> <a
                                      href="<?php echo e(basic_information()->website_link); ?>"><?php echo e(basic_information()->company_name); ?></a>
                              </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <script src="http://maps.google.com/maps/api/js?sensor=true"></script>
    </div>
</div>

<script src="<?php echo e(asset('assets/vendors/jquery/dist/jquery.min.js')); ?>" type="text/javascript"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/scripts/main.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/scripts/user_custom.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/dashboard/layout/app.blade.php ENDPATH**/ ?>