<div class="col-md-3 left_col">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a href="<?php echo e(route('admin')); ?>" class="site_title"><img
                        src="<?php echo e(asset('storage/logo/'.basic_information()->company_logo)); ?>"></a>
        </div>

        <div class="clearfix"></div>
        <!-- /menu profile quick info -->

        <br/>

        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                    <li><a href="<?php echo e(route('admin')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                    <li><a><i class="fa mdi mdi-google-maps"></i> Country Manage <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(route('AdminCountry')); ?>">Country</a></li>
                            <li><a href="<?php echo e(route('AdminState')); ?>">State</a></li>
                            <li><a href="<?php echo e(route('AdminCity')); ?>">City</a></li>
                        </ul>
                    </li>
                    <li><a><i class="fa mdi mdi-export"></i> Shipping Price <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(route('AdminInternational')); ?>">International</a></li>
                            <li><a href="<?php echo e(route('AdminDomestic')); ?>">Domestic</a></li>
                        </ul>
                    </li>
                    <li><a><i class="fa mdi mdi-cube-send"></i> Shipment <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(route('AdminShipment')); ?>">Shipment List</a></li>
                            <li><a href="#">Create a new shipment</a></li>
                        </ul>
                    </li>
                    <li><a><i class="fa mdi mdi-book-multiple"></i> Manage Shipment <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="#">All</a></li>
                            <li><a href="#">Pending</a></li>
                            <li><a href="#">Rejected</a></li>
                            <li><a href="#">Delivered</a></li>
                        </ul>
                    </li>
                    <li><a><i class="fa mdi mdi-view-week"></i> Container <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="#">Container List</a></li>
                            <li><a href="#">Create Container</a></li>
                        </ul>
                    </li>
                    <li><a href="<?php echo e(route('AdminCustomerList')); ?>"><i class="fa mdi mdi-account-multiple-plus"></i> Customer List</a>
                    </li>
                    <li><a href="<?php echo e(route('AdminBookingRequest')); ?>"><i class="fa mdi mdi-book-plus"></i> Booking Request</a>
                    </li>
                    <li><a href="#"><i class="fa mdi mdi-package"></i> Shipping Rate Calculate</a>
                    </li>
                    <li><a><i class="fa mdi mdi-currency-usd"></i> Transaction <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="#">Billing</a></li>
                            <li><a href="#">Payments</a></li>
                        </ul>
                    </li>
                    <li><a><i class="fa mdi mdi-settings-box"></i> Website Management <span class="fa fa-chevron-down"></span></a>
                        <ul class="nav child_menu">
                            <li><a href="<?php echo e(route('BasicInformation')); ?>">Basic Information</a></li>
                            <li><a href="<?php echo e(route('SliderManage')); ?>">Slider Manage</a></li>
                            <li><a href="<?php echo e(route('AdminContact')); ?>">Contact us</a></li>
                            <li><a href="<?php echo e(route('AdminTestimonial')); ?>">Testimonials</a></li>
                            <li><a href="<?php echo e(route('AdminSponsor')); ?>">Sponsor</a></li>
                            <li><a href="<?php echo e(route('OurService')); ?>">Our Service</a></li>
                            <li><a href="<?php echo e(route('AdminFaq')); ?>">Faq</a></li>
                            <li><a href="<?php echo e(route('OurInformation')); ?>">Our Information</a></li>
                            <li><a href="<?php echo e(route('AdminNews')); ?>">News</a></li>
                        </ul>
                    </li>
               </ul>
            </div>

        </div>
        <!-- /sidebar menu -->
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/inc/sidebar.blade.php ENDPATH**/ ?>