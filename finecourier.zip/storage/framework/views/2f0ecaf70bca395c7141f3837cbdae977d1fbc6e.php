<?php $__env->startSection('pageTitle','Country Manage'); ?>
<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Country Manage</h3>
                </div>
                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">
                            <i class="fa fa-plus fs-13 m-r-3"></i> Add New Country
                        </button>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <table id="datatable-buttons"
                                   class="table table-striped table-bordered dataTable no-footer dtr-inline">
                                <thead>
                                <tr class="bg-dark">
                                    <th>NumericCode</th>
                                    <th>Code</th>
                                    <th>Name</th>
                                    <th>Currency</th>
                                    <th>PhonePrefix</th>
                                    <th>Geonames Code</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <th scope="row"><?php echo e($countries['numericCode']); ?></th>
                                        <th scope="row"><?php echo e($countries['code']); ?></th>
                                        <th scope="row"><?php echo e($countries['name']); ?></th>
                                        <th scope="row"><?php echo e($countries['currency']); ?></th>
                                        <th scope="row"><?php echo e($countries['phonePrefix']); ?></th>
                                        <th scope="row"><?php echo e($countries['geonamesCode']); ?></th>

                                        <td>
                                            <?php if(check_active_country($countries['code'])): ?>
                                                <button type="button" id="<?php echo e($countries['code']); ?>"
                                                        class="btn btn-success btn-xs Change">Active
                                                </button>
                                            <?php else: ?>
                                                <button type="button" id="<?php echo e($countries['code']); ?>"
                                                        class="btn btn-info btn-xs Change">Inactive
                                                </button>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <div class="x_panel">
                        <div class="x_title">
                            <h2>
                                <small>Country Information add</small>
                            </h2>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br>
                            <form id="demo-form2" method="post"
                                  action="<?php echo e(route('AdminCountryAdd')); ?>"
                                  class="form-horizontal form-label-left input_mask">
                                <?php echo e(csrf_field()); ?>


                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="code">Code*:</label>
                                    <input type="text" class="form-control" placeholder="BD" name="code" id="code"
                                           value="<?php echo e(old('code')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="currency">Currency*:</label>
                                    <input type="text" class="form-control" placeholder="BDT" name="currency"
                                           id="currency" value="<?php echo e(old('currency')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="name">Name*:</label>
                                    <input type="text" class="form-control" placeholder="Bangladesh" name="name"
                                           id="name" value="<?php echo e(old('name')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="code3">Code3:</label>
                                    <input type="text" class="form-control" placeholder="BGD" name="code3" id="code3"
                                           value="<?php echo e(old('code3')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="isoCode">ISO Code:</label>
                                    <input type="text" class="form-control" placeholder="BD" name="isoCode" id="isoCode"
                                           value="<?php echo e(old('isoCode')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="numericCode">Numeric Code:</label>
                                    <input type="text" class="form-control" placeholder="050" name="numericCode"
                                           id="numericCode" value="<?php echo e(old('numericCode')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="geonamesCode">Geonames Code:</label>
                                    <input type="number" class="form-control" placeholder="1210997" name="geonamesCode"
                                           id="geonamesCode" value="<?php echo e(old('geonamesCode')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="fipsCode">Fips Code:</label>
                                    <input type="text" class="form-control" name="fipsCode" id="fipsCode"
                                           value="<?php echo e(old('fipsCode')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="area">Area:</label>
                                    <input type="number" class="form-control" placeholder="144000" name="area" id="area"
                                           value="<?php echo e(old('area')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="mobileFormat">Mobile Format:</label>
                                    <input type="text" class="form-control" name="mobileFormat" id="mobileFormat"
                                           value="<?php echo e(old('mobileFormat')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="phonePrefix">Phone Prefix:</label>
                                    <input type="text" class="form-control" placeholder="880" name="phonePrefix"
                                           id="phonePrefix" value="<?php echo e(old('phonePrefix')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="landlineFormat">Land line Format:</label>
                                    <input type="text" class="form-control" name="landlineFormat" id="landlineFormat"
                                           value="<?php echo e(old('landlineFormat')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="trunkPrefix">Trunk Prefix:</label>
                                    <input type="text" class="form-control" name="trunkPrefix" id="trunkPrefix"
                                           value="<?php echo e(old('trunkPrefix')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="population">Population:</label>
                                    <input type="number" class="form-control" placeholder="156118464" name="population"
                                           id="population" value="<?php echo e(old('population')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="continent">Continent:</label>
                                    <input type="text" class="form-control" name="continent" id="continent"
                                           value="<?php echo e(old('continent')); ?>">
                                </div>
                                <div class="col-md-6 col-sm-6 col-xs-12 form-group has-feedback">
                                    <label for="language">Language:</label>
                                    <input type="text" class="form-control" placeholder="bn" name="language"
                                           id="language" value="<?php echo e(old('language')); ?>">
                                </div>
                                <hr>
                                <div class="col-md-12 form-group has-feedback ">
                                    <button type="submit" class="btn btn-success pull-right"><i
                                            class="mdi mdi-content-save m-r-3"></i>Save
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal">
                                        <i class="mdi mdi-cancel m-r-3"></i>Cancel
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet"/>
    <!-- Datatables -->
    <link href="<?php echo e(asset('assets/vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>"
          rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>"
          rel="stylesheet">
    <link href="<?php echo e(asset('assets/vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- Datatables -->
    <script src="<?php echo e(asset('assets/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/jszip/dist/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/pdfmake/build/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/pdfmake/build/vfs_fonts.js')); ?>"></script>


    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        var CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');
        $('.Change').click(function () {
            let id = $(this).attr('id'), action;
            let clases = $(this);
            if ($(this).hasClass("btn-success")) {
                action = 'inactive';
                $.ajax({
                    url: '<?php echo e(route('AdminCountryChange')); ?>',
                    type: 'post',
                    data: {_token: CSRF_TOKEN, id: id, action: action},
                    success: function (response) {
                        $(clases).toggleClass('btn-success btn-info');
                        $(clases).html('Inactive');
                    }
                });
            } else {
                action = 'active';
                $.ajax({
                    url: '<?php echo e(route('AdminCountryChange')); ?>',
                    type: 'post',
                    data: {_token: CSRF_TOKEN, id: id, action: action},
                    success: function (response) {
                        $(clases).toggleClass('btn-info btn-success');
                        $(clases).html('Active');
                    }
                });

            }
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/country/country.blade.php ENDPATH**/ ?>