<?php $__env->startSection('content'); ?>


    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Booking request <?php echo e($shipping->booking_type==1?'International':'Domestic'); ?></h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <div class="row">
                                <div class="col-md-6">
                                    <?php if($shipping->booking_type == 2): ?>
                                        <p><i class="fa fa-calendar"></i> <?php echo e($shipping->pickup_date); ?></p>
                                    <?php endif; ?>
                                    <p><i class="fa fa-user"></i> <?php echo e($shipping->shipper_name); ?></p>
                                    <p>
                                        <i class="fa fa-map-marker"></i> <?php echo e(get_country_name_by_code($shipping->from_country)->name); ?>

                                    </p>
                                    <p><i class="fa fa-phone"></i> <?php echo e($shipping->shipper_phone); ?></p>
                                    <p><i class="fa fa-mail-reply"></i> <?php echo e($shipping->shipper_email); ?></p>
                                    <p><i class="fa fa-globe"></i> <?php echo e($shipping->shipper_address); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <?php if($shipping->booking_type == 2): ?>
                                        <p><i class="fa fa-calendar"></i> <?php echo e($shipping->pickup_delivery); ?></p>
                                    <?php endif; ?>
                                    <p><i class="fa fa-user"></i> <?php echo e($shipping->receiver_name); ?></p>
                                    <?php if($shipping->booking_type == 1): ?>
                                        <p>
                                            <i class="fa fa-map-marker"></i> <?php echo e(get_country_name_by_code($shipping->to_country)->name); ?>

                                        </p>
                                    <?php endif; ?>
                                    <p><i class="fa fa-phone"></i> <?php echo e($shipping->receiver_phone); ?></p>
                                    <p><i class="fa fa-mail-reply"></i> <?php echo e($shipping->receiver_email); ?></p>
                                    <p><i class="fa fa-globe"></i> <?php echo e($shipping->receiver_address); ?></p>
                                </div>
                            </div>
                            <table class="table table-bordered table-hover projects">
                                <thead>
                                <tr>
                                    <th>Shipping Type</th>
                                    <th>Delivery Type</th>
                                    <th>Weight</th>
                                    <th>Dimension</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><?php echo e($shipping->shipping_type); ?></td>
                                    <td><?php echo e($shipping->delivery_type); ?></td>
                                    <td><?php echo e($shipping->weight.' '.$shipping->weight_type); ?></td>
                                    <td><?php echo e($shipping->dimenshion); ?></td>
                                </tr>
                                </tbody>
                            </table>

                            <div class="row">
                                <a href="<?php echo e(route('AdminBookingRequestAction','delete='.base64_encode($shipping->id))); ?>"
                                   class="btn btn-danger pull-right delete">Delete</a>
                                <a href="<?php echo e(route('AdminBookingRequestAction','block='.base64_encode($shipping->id))); ?>"
                                   class="btn btn-warning pull-right">Block</a>
                                <button class="btn btn-success pull-right">Booking Approve</button>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.css')); ?>" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.js')); ?>"></script>
    <script>

        $('.delete').click(function (e) {
            e.preventDefault(); // Prevent the href from redirecting directly
            var linkURL = $(this).attr("href");
            swal({
                title: "Sure want to remove?",
                text: "If you click 'OK' file will be remove",
                type: "warning",
                showCancelButton: true
            }, function () { // Redirect the user | linkURL is href url
                window.location.href = linkURL;
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/shipment/booking_shipment_view.blade.php ENDPATH**/ ?>