<?php $__env->startSection('pageTitle','Booking History'); ?>
<?php $__env->startSection('content'); ?>


    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Booking request <?php echo e($shipping->booking_type==1?'International':'Domestic'); ?></h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <div class="row">
                                <div class="col-12">
                                    <a href="<?php echo e(route('AdminBookingRequestAction','delete='.base64_encode($shipping->id))); ?>"
                                       class="btn btn-danger pull-right delete"><i class="mdi mdi-delete"></i> Delete</a>
                                    <?php if($shipping->status == 0): ?>
                                        <button class="btn btn-success pull-right approve">Booking Approve</button>
                                    <?php else: ?>
                                        <?php if($shipping->status == 5): ?>
                                            <a href="<?php echo e(route('AdminBookingRequestAction','unblock='.base64_encode($shipping->id))); ?>"
                                               class="btn btn-primary pull-right"
                                               data-toggle="tooltip"
                                               data-placement="top" title=""
                                               data-original-title="You can approve shipment again"><i class="mdi mdi-approval"></i> Approve</a>
                                        <?php else: ?>
                                            <a href="<?php echo e(route('AdminBookingRequestAction','block='.base64_encode($shipping->id))); ?>"
                                               class="btn btn-warning pull-right" style="" data-toggle="tooltip"
                                               data-placement="top" title=""
                                               data-original-title="You can block this shipment"><i class="mdi mdi-block-helper"></i> Block</a>
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    <button class="btn btn-warning pull-right send-mail"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            data-original-title="Send mail Shipper"><i class="mdi mdi-email"></i> Send Email
                                    </button>
                                </div>
                                <div class="col-12">
                                    <img
                                        src="<?php echo e(asset('storage/logo/'.basic_information()->company_logo)); ?>"
                                        width="200px">
                                </div>
                                <div class="col-sm-6">
                                    <?php echo DNS1D::getBarcodeHTML($shipping->tracking_code, "EAN13"); ?>

                                    <p class="text-dark" style="font-size: 15px">Tracking Code:
                                        <?php echo e($shipping->tracking_code); ?></p>
                                </div>
                                <div class="col-sm-6 text-right">
                                    Date: <?php echo e($shipping->created_at->format('d M, Y')); ?>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <?php if($shipping->booking_type == 2): ?>
                                        <p><i class="fa fa-calendar"></i> <?php echo e($shipping->pickup_date); ?></p>
                                    <?php endif; ?>
                                    <p><i class="fa fa-user"></i> <?php echo e($shipping->shipper_name); ?></p>
                                    <p>
                                        <i class="fa fa-map-marker"></i> <?php echo e(get_country_name_by_code($shipping->from_country)->name); ?>

                                    </p>
                                    <p><i class="fa fa-phone"></i> <?php echo e($shipping->shipper_phone); ?></p>
                                    <p><i class="fa fa-mail-reply"></i> <?php echo e($shipping->shipper_email); ?></p>
                                    <p><i class="fa fa-globe"></i> <?php echo e($shipping->shipper_address); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <?php if($shipping->booking_type == 2): ?>
                                        <p><i class="fa fa-calendar"></i> <?php echo e($shipping->pickup_delivery); ?></p>
                                    <?php endif; ?>
                                    <p><i class="fa fa-user"></i> <?php echo e($shipping->receiver_name); ?></p>
                                    <?php if($shipping->booking_type == 1): ?>
                                        <p>
                                            <i class="fa fa-map-marker"></i> <?php echo e(get_country_name_by_code($shipping->to_country)->name); ?>

                                        </p>
                                    <?php endif; ?>
                                    <p><i class="fa fa-phone"></i> <?php echo e($shipping->receiver_phone); ?></p>
                                    <p><i class="fa fa-mail-reply"></i> <?php echo e($shipping->receiver_email); ?></p>
                                    <p><i class="fa fa-globe"></i> <?php echo e($shipping->receiver_address); ?></p>
                                </div>
                            </div>
                            <table class="table table-bordered table-hover projects">
                                <thead>
                                <tr>
                                    <th>Shipping Type</th>
                                    <th>Delivery Type</th>
                                    <th>Weight</th>
                                    <th>Dimension</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr>
                                    <td><?php echo e($shipping->shipping_type); ?></td>
                                    <td><?php echo e($shipping->delivery_type); ?></td>
                                    <td><?php echo e($shipping->weight.' '.$shipping->weight_type); ?></td>
                                    <td><?php echo e($shipping->dimenshion); ?></td>
                                </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <div class="x_panel">
                        <div class="x_title">
                            <h4>Approve booking request</h4>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br>
                            <form method="post" action="<?php echo e(route('AdminBookingRequestApprove')); ?>"
                                  class="form-horizontal form-label-left input_mask">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($shipping->id); ?>" name="id">
                                <div class="col-md-12 form-group text-left" style="padding-left: 0;">
                                    <label for="usr3">Booking Shipment Cost:</label>
                                    <div class="input-group" style="width: 100%">
                                        <input type="text" name="price"
                                               class="form-control" placeholder="Enter Price....">
                                        <span class="input-group-addon"
                                              style="width:0px; padding-left:0px; padding-right:0px; border:none;"></span>
                                        <select id="searchbygenerals_currency" name="currency"
                                                class="form-control">
                                            <?php $__currentLoopData = $country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $countries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($shipping->from_country == $countries->code): ?>
                                                    <option
                                                        value="<?php echo e($countries->currency); ?>"
                                                        selected><?php echo e($countries->currency); ?></option>
                                                <?php else: ?>
                                                    <option
                                                        value="<?php echo e($countries->currency); ?>"><?php echo e($countries->currency); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-12 form-group has-feedback" style="margin-top: 10px">
                                    <button type="submit" class="btn btn-success pull-right send-button"
                                            id="load"
                                            data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing"><i
                                            class="mdi mdi-approval m-r-3"></i>Approve
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal">
                                        <i class="mdi mdi-cancel m-r-3"></i>Cancel
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                </form>

            </div>

        </div>
    </div>

    <!-- Modal -->
    <div id="myModal2" class="modal fade bs-example-modal-lg" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <div class="x_panel">
                        <div class="x_title">
                            <h4>Send Mail shipper</h4>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br>
                            <form id="upload_form" method="post" class="form-horizontal form-label-left input_mask">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="" name="id" id="country_id">
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Shipper Mail Address:</label>
                                    <input type="email" class="form-control" name="mail" id="mail"
                                           value="<?php echo e($shipping->shipper_email); ?>" readonly>
                                </div>
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Subject:</label>
                                    <input type="text" class="form-control" name="subject" id="subject" placeholder="Message subject">
                                </div>
                                <div class="col-xs-12">
                                    <label for="language">Message:</label>
                                    <textarea id="editor1" name="message"></textarea>
                                    <script>
                                        CKEDITOR.replace('editor1', {
                                            customConfig: "<?php echo e(asset('assets/vendors/ckeditor/config.js')); ?>"
                                        });
                                    </script>
                                </div>
                                <hr>
                                <div class="col-md-12 form-group has-feedback" style="margin-top: 10px">
                                    <button type="submit" class="btn btn-success pull-right send-button"
                                            id="load"
                                            data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing"><i
                                            class="mdi mdi-send m-r-3"></i>Send Mail
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal">
                                        <i class="mdi mdi-cancel m-r-3"></i>Cancel
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('assets/vendors/ckeditor/ckeditor.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.js')); ?>"></script>
    <script>
        <?php if(session()->has('message')): ?>
        swal({
            title: 'Message',
            text: "<?php echo e(session()->get('message')); ?>",
            type: 'info',
            confirmButtonText: 'Ok'
        });
        <?php endif; ?>

        $('.delete').click(function (e) {
            e.preventDefault(); // Prevent the href from redirecting directly
            var linkURL = $(this).attr("href");
            swal({
                title: "Sure want to remove?",
                text: "If you click 'OK' file will be remove",
                type: "warning",
                showCancelButton: true
            }, function () { // Redirect the user | linkURL is href url
                window.location.href = linkURL;
            });
        });

        $(document).on('click', '.approve', function () {
            $('#myModal').modal('show');
            $("#upload_form").trigger("reset");
        });

        $(document).on('click', '.send-mail', function () {
            $('#myModal2').modal('show');
            $("#upload_form").trigger("reset");
        });

        $('#upload_form').on('submit', function () {
            event.preventDefault();
            let form = new FormData(this);
            $('.send-button').button('loading');

            $.ajax({
                url: "<?php echo e(route('AdminSandMail')); ?>",
                method: "POST",
                cache: false,
                contentType: false,
                processData: false,
                data: form,
                dataType: 'json',
                error: function (data) {
                    if (data.status === 422) {
                        var errors = $.parseJSON(data.responseText);
                        let allData = '', mainData = '';
                        $.each(errors, function (key, value) {
                            if ($.isPlainObject(value)) {
                                $.each(value, function (key, value) {
                                    allData += value + "<br/>";
                                });
                            } else {
                                mainData += value + "<br/>";
                            }
                        });
                        $('.send-button').button('reset');
                        swal({
                            title: mainData,
                            text: allData,
                            type: 'error',
                            html: true,
                            confirmButtonText: 'Ok'
                        })
                    }
                },
                success: function (data) {
                    if(data == 1){
                        $('.send-button').button('reset');
                        $('#myModal2').modal('hide');
                        swal({
                            title: "Congratulation",
                            text: "Your message send to the shipper",
                            type: 'success',
                            html: true,
                            confirmButtonText: 'Ok'
                        })
                    }
                }
            });
        });

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/shipment/booking_shipment_view.blade.php ENDPATH**/ ?>