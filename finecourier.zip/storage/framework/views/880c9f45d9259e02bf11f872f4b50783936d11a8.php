<?php $__env->startSection('pageTitle','Driver Dashboard'); ?>
<?php $__env->startSection('content'); ?>

    <div class="right_col" role="main" style="min-height: 1962px;">


    </div>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- jQuery Sparklines -->
    <script src="<?php echo e(asset('assets/')); ?><?php echo e(asset('assets/')); ?>vendors/jquery-sparkline/dist/jquery.sparkline.min.js"></script>
    <!-- morris.js -->
    <script src="<?php echo e(asset('assets/vendors/raphael/raphael.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/morris.js/morris.min.js')); ?>"></script>
    <!-- Skycons -->
    <script src="<?php echo e(asset('assets/vendors/skycons/skycons.js')); ?>"></script>
    <!-- Flot -->
    <script src="<?php echo e(asset('assets/vendors/Flot/jquery.flot.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/Flot/jquery.flot.pie.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/Flot/jquery.flot.time.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/Flot/jquery.flot.stack.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/Flot/jquery.flot.resize.js')); ?>"></script>
    <!-- Flot plugins -->
    <script src="<?php echo e(asset('assets/vendors/flot.orderbars/js/jquery.flot.orderBars.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/flot-spline/js/jquery.flot.spline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/flot.curvedlines/curvedLines.js')); ?>"></script>
    <!-- DateJS -->
    <script src="<?php echo e(asset('assets/vendors/DateJS/build/date.js')); ?>"></script>
    <!-- bootstrap-daterangepicker -->
    <script src="<?php echo e(asset('assets/vendors/moment/min/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('driver.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/driver/index.blade.php ENDPATH**/ ?>