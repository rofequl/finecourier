<?php $__env->startSection('pageTitle','Shipping History'); ?>
<?php $__env->startSection('content'); ?>

    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Shipment Information <?php echo e($shipment->shipment==1?'International':'Domestic'); ?></h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_content">
                            <div class="row">
                                <div class="col-12">
                                    <?php if($shipment->block == 1): ?>
                                        <a href="<?php echo e(route('AdminShipmentBlock','unblock='.base64_encode($shipment->id))); ?>"
                                           class="btn btn-success pull-right"
                                           data-toggle="tooltip"
                                           data-placement="top"
                                           data-original-title="Shipment Approve"><i
                                                class="mdi mdi-block-helper"></i> Approve
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('AdminShipmentBlock','block='.base64_encode($shipment->id))); ?>"
                                           class="btn btn-danger pull-right"
                                           data-toggle="tooltip"
                                           data-placement="top"
                                           data-original-title="Shipment rejected"><i
                                                class="mdi mdi-block-helper"></i> Reject
                                        </a>
                                    <?php endif; ?>
                                    <button class="btn btn-warning pull-right status"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            data-original-title="Shipment Status update"><i
                                            class="mdi mdi-comment-question-outline"></i> Status
                                    </button>
                                    <button class="btn btn-warning pull-right send-mail"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            data-original-title="Send mail Shipper"><i class="mdi mdi-email"></i> Send
                                        Email
                                    </button>
                                    <button class="btn btn-warning pull-right driver-assign"
                                            data-toggle="tooltip"
                                            data-placement="top"
                                            data-original-title="Driver assign by shipment"><i
                                            class="mdi mdi-truck-fast"></i> Driver Assign
                                    </button>
                                </div>
                                <div class="col-12">
                                    <img
                                        src="<?php echo e(asset('storage/logo/'.basic_information()->company_logo)); ?>"
                                        width="200px">
                                </div>
                                <div class="col-sm-6">
                                    <?php echo DNS1D::getBarcodeHTML($shipment->tracking_code, "EAN13"); ?>

                                    <p class="text-dark" style="font-size: 15px">Tracking Code:
                                        <?php echo e($shipment->tracking_code); ?></p>
                                </div>
                                <div class="col-sm-6 text-right">
                                    Date: <?php echo e($shipment->created_at->format('d M, Y')); ?>

                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <h4 style="font-weight: 700;font-size: 20px;color: #6f5858;">Shipper</h4>
                                    <p class="text-success mb-0" style="font-size: 20px">
                                        <i class="fa fa-user mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->shipper_address)->name); ?>

                                    </p>
                                    <p class="text-black mb-0" style="font-size: 15px">
                                        <i class="fa fa-phone-square mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->shipper_address)->phone_one); ?>

                                    </p>
                                    <p class="text-black mb-0" style="font-size: 15px">
                                        <i class="fa fa-envelope mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->shipper_address)->email); ?>

                                    </p>
                                    <p class="text-black" style="font-size: 15px">
                                        <i class="fa fa-globe mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_city_name_by_code(get_address_by_id($shipment->shipper_address)->country,get_address_by_id($shipment->shipper_address)->state,get_address_by_id($shipment->shipper_address)->city)->name); ?>

                                        ,
                                        <?php echo e(get_state_name_by_code(get_address_by_id($shipment->shipper_address)->country,get_address_by_id($shipment->shipper_address)->state)->name); ?>

                                        ,
                                        <?php echo e(get_country_name_by_code(get_address_by_id($shipment->shipper_address)->country)->name); ?>

                                        ,
                                        <?php echo e(get_address_by_id($shipment->shipper_address)->post_code); ?>

                                    </p>
                                </div>
                                <div class="col-md-6">
                                    <h4 style="font-weight: 700;font-size: 20px;color: #6f5858;">Receiver</h4>
                                    <p class="text-success mb-0" style="font-size: 20px">
                                        <i class="fa fa-user mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->receiver_address)->name); ?>

                                    </p>
                                    <p class="text-black mb-0" style="font-size: 15px">
                                        <i class="fa fa-phone-square mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->shipper_address)->phone_one); ?>

                                    </p>
                                    <p class="text-black mb-0" style="font-size: 15px">
                                        <i class="fa fa-envelope mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->shipper_address)->email); ?>

                                    </p>
                                    <p class="text-black" style="font-size: 15px">
                                        <i class="fa fa-globe mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_city_name_by_code(get_address_by_id($shipment->receiver_address)->country,get_address_by_id($shipment->receiver_address)->state,get_address_by_id($shipment->receiver_address)->city)->name); ?>

                                        ,
                                        <?php echo e(get_state_name_by_code(get_address_by_id($shipment->receiver_address)->country,get_address_by_id($shipment->receiver_address)->state)->name); ?>

                                        ,
                                        <?php echo e(get_country_name_by_code(get_address_by_id($shipment->receiver_address)->country)->name); ?>

                                        ,
                                        <?php echo e(get_address_by_id($shipment->receiver_address)->post_code); ?>

                                    </p>
                                </div>
                                <div class="col-12" style="padding: 10px;">
                                    <h4 style="font-weight: 700;font-size: 20px;color: #6f5858;">Biller address</h4>
                                    <p class="text-success mb-0" style="font-size: 20px">
                                        <i class="fa fa-user mr-2" aria-hidden="true"></i>
                                        <?php echo e(get_address_by_id($shipment->biller_address)->name); ?>

                                    </p>
                                    <div class="row">
                                        <div class="col-md-4">
                                            <p class="text-black mb-0" style="font-size: 15px">
                                                <i class="fa fa-phone-square mr-2" aria-hidden="true"></i>
                                                <?php echo e(get_address_by_id($shipment->biller_address)->phone_one); ?>

                                            </p>
                                        </div>
                                        <div class="col-md-4">
                                            <p class="text-black mb-0" style="font-size: 15px">
                                                <i class="fa fa-envelope mr-2" aria-hidden="true"></i>
                                                <?php echo e(get_address_by_id($shipment->biller_address)->email); ?>

                                            </p>
                                        </div>
                                        <div class="col-md-4">
                                            <p class="text-black mt-2" style="font-size: 15px">
                                                <i class="fa fa-globe mr-2" aria-hidden="true"></i>
                                                <?php echo e(get_city_name_by_code(get_address_by_id($shipment->biller_address)->country,get_address_by_id($shipment->biller_address)->state,get_address_by_id($shipment->biller_address)->city)->name); ?>

                                                ,
                                                <?php echo e(get_state_name_by_code(get_address_by_id($shipment->biller_address)->country,get_address_by_id($shipment->biller_address)->state)->name); ?>

                                                ,
                                                <?php echo e(get_country_name_by_code(get_address_by_id($shipment->biller_address)->country)->name); ?>

                                                ,
                                                <?php echo e(get_address_by_id($shipment->biller_address)->post_code); ?>

                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="table-responsive">
                                        <table class="align-middle mb-0 table table-bordered text-center">
                                            <thead>
                                            <tr>
                                                <th>No. of Peace</th>
                                                <th>Shipping Type</th>
                                                <th>Origin Country</th>
                                                <th>Weight</th>
                                                <th>Good Value</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            <tr>
                                                <td><?php echo e($shipment->peace); ?></td>
                                                <td><?php echo e($shipment->shipping_type); ?></td>
                                                <td><?php echo e(get_country_name_by_code($shipment->origin_country)->name); ?></td>
                                                <td><?php echo e($shipment->weight); ?> <?php echo e($shipment->weight_type); ?></td>
                                                <td><?php echo e($shipment->good_value); ?> <?php echo e($shipment->origin_currency); ?></td>
                                            </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-5">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left">
                                                    <div class="widget-heading">Service type:
                                                        <small>
                                                            <?php if($shipment->delivery_type == 'Regular'): ?>
                                                                REGULAR
                                                                (I am importing and I will pay when)
                                                            <?php else: ?>
                                                                EXPRESS
                                                                (I am exporting and I will pay when I ship)
                                                            <?php endif; ?>
                                                        </small>
                                                    </div>
                                                    <br>
                                                    <div class="widget-heading">Payment:
                                                        <small>
                                                            <?php if($shipment->payment_type == 1): ?>
                                                                In cash by the shipper
                                                            <?php else: ?>
                                                                By credit card by the shipper
                                                            <?php endif; ?>
                                                        </small>
                                                    </div>
                                                    <br>
                                                    # We’ve notified the shipper and receiver.
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-5">
                                    <div class="widget-content">
                                        <div class="widget-content-outer">
                                            <div class="widget-content-wrapper">
                                                <div class="widget-content-left w-100">
                                                    <div class="card card-body shadow-none p-1" id="FoundPrice"
                                                         style="text-align:center;border: 1px solid #ddd;font-size:15px;cursor: pointer;">
                                                        <div style="font-size: 20px;height: 100px;width: 107px;margin: 20px 0;border: 1px dotted blueviolet;border-radius: 50%;padding-top: 35px;display: inline-block;margin-left: auto;
                            margin-right: auto;" id="PriceShowing">
                                                            <?php echo e($shipment->price); ?>

                                                            <?php echo e($shipment->currency); ?>

                                                        </div>
                                                        <h4>
                                                            <span id="NotFoundState1"><?php echo e($shipment->address_one); ?></span>
                                                            <i class="fa fa-arrow-right" aria-hidden="true"></i>
                                                            <span id="NotFoundState21"><?php echo e($shipment->address_two); ?></span>
                                                        </h4>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--Mail Modal -->
    <div id="myModal" class="modal fade bs-example-modal-lg" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <div class="x_panel">
                        <div class="x_title">
                            <h4>Send Mail shipper</h4>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br>
                            <form id="upload_form" method="post" class="form-horizontal form-label-left input_mask">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="" name="id" id="country_id">
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Shipper Mail Address:</label>
                                    <input type="email" class="form-control" name="mail" id="mail"
                                           value="<?php echo e(get_address_by_id($shipment->shipper_address)->email); ?>" readonly>
                                </div>
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Subject:</label>
                                    <input type="text" class="form-control" name="subject" id="subject"
                                           placeholder="Message subject">
                                </div>
                                <div class="col-xs-12">
                                    <label for="language">Message:</label>
                                    <textarea id="editor1" name="message"></textarea>
                                    <script>
                                        CKEDITOR.replace('editor1', {
                                            customConfig: "<?php echo e(asset('assets/vendors/ckeditor/config.js')); ?>"
                                        });
                                    </script>
                                </div>
                                <hr>
                                <div class="col-md-12 form-group has-feedback" style="margin-top: 10px">
                                    <button type="submit" class="btn btn-success pull-right send-button"
                                            id="load"
                                            data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing"><i
                                            class="mdi mdi-send m-r-3"></i>Send Mail
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal">
                                        <i class="mdi mdi-cancel m-r-3"></i>Cancel
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                </form>

            </div>

        </div>
    </div>

    <!--Driver Modal -->
    <div id="myModal2" class="modal fade bs-example-modal-lg" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <div class="x_panel">
                        <div class="x_title">
                            <h4>Driver Assign by Shipment</h4>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br>
                            <form id="upload_form2" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($shipment->id); ?>" name="id">
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Driver:</label>
                                    <select class="select2_single" name="driver"
                                            id="driver_id">
                                        <option></option>
                                        <?php $__currentLoopData = $driver; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $drivers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($drivers->driver_id == $shipment->driver): ?>
                                                <option value="<?php echo e($drivers->driver_id); ?>"
                                                        selected><?php echo e($drivers->driver_id.' ('.$drivers->first_name.' '.$drivers->last_name.')'); ?></option>
                                            <?php else: ?>
                                                <option
                                                    value="<?php echo e($drivers->driver_id); ?>"><?php echo e($drivers->driver_id.' ('.$drivers->first_name.' '.$drivers->last_name.')'); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <hr>
                                <div class="col-md-12 form-group has-feedback" style="margin-top: 10px">
                                    <button type="submit" class="btn btn-success pull-right send-button"
                                            id="load"
                                            data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing"><i
                                            class="mdi mdi-truck-fast m-r-3"></i>Driver Assign
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal">
                                        <i class="mdi mdi-cancel m-r-3"></i>Cancel
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                </form>

            </div>

        </div>
    </div>

    <!--Status Modal -->
    <div id="myModal3" class="modal fade bs-example-modal-lg" role="dialog">
        <div class="modal-dialog modal-lg">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-body">
                    <div class="x_panel">
                        <div class="x_title">
                            <h4>Shipment Status Update</h4>
                            <div class="clearfix"></div>
                        </div>
                        <div class="x_content">
                            <br>
                            <form id="upload_form3" method="post">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" value="<?php echo e($shipment->tracking_code); ?>" name="tracking_code">
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Shipment Status:</label>
                                    <select class="select2_single" name="status"
                                            id="driver_id">
                                        <option></option>
                                        <option value="1" <?php echo e($shipment->status==1?'selected':''); ?>>Confirm Shipment
                                            (<?php echo e($shipment->created_at->format('d M, Y')); ?>)
                                        </option>
                                        <option value="2" <?php echo e($shipment->status==2?'selected':''); ?>>
                                            Picked <?php echo e(get_shipment_status($shipment->tracking_code, 2)? '('.get_shipment_status($shipment->tracking_code, 2)->time.')':''); ?></option>
                                        <option value="3" <?php echo e($shipment->status==3?'selected':''); ?>>
                                            Container <?php echo e(get_shipment_status($shipment->tracking_code, 3)? '('.get_shipment_status($shipment->tracking_code, 3)->time.')':''); ?></option>
                                        <option value="4" <?php echo e($shipment->status==4?'selected':''); ?>>
                                            Shipped <?php echo e(get_shipment_status($shipment->tracking_code, 4)? '('.get_shipment_status($shipment->tracking_code, 4)->time.')':''); ?></option>
                                        <option value="5" <?php echo e($shipment->status==5?'selected':''); ?>>
                                            Delivered <?php echo e(get_shipment_status($shipment->tracking_code, 5)? '('.get_shipment_status($shipment->tracking_code, 5)->time.')':''); ?></option>
                                    </select>
                                </div>
                                <div class="col-xs-12 form-group">
                                    <label for="code">Date:</label>
                                    <div class='input-group date' id='myDatepicker4'>
                                        <input type='text' name="time" class="form-control" readonly="readonly"/>
                                        <span class="input-group-addon">
                                           <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                                <div class="col-xs-12 form-group has-feedback">
                                    <label for="code">Location:</label>
                                    <input type="text" placeholder="Enter the location" class="form-control"
                                           name="location">
                                </div>
                                <hr>
                                <div class="col-md-12 form-group has-feedback" style="margin-top: 10px">
                                    <button type="submit" class="btn btn-success pull-right send-button"
                                            id="load"
                                            data-loading-text="<i class='fa fa-spinner fa-spin '></i> Processing"><i
                                            class="mdi mdi-comment-question-outline m-r-3"></i>Update Status
                                    </button>
                                    <button type="button" class="btn btn-primary pull-right" data-dismiss="modal">
                                        <i class="mdi mdi-cancel m-r-3"></i>Cancel
                                    </button>
                                </div>

                            </form>
                        </div>
                    </div>
                </div>
                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(asset('assets/vendors/ckeditor/ckeditor.js')); ?>"></script>
    <!-- bootstrap-datetimepicker -->
    <link href="<?php echo e(asset('assets/vendors/bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.css')); ?>"
          rel="stylesheet">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- bootstrap-datetimepicker -->
    <script
        src="<?php echo e(asset('assets/vendors/bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/vendors/sweetalert/sweetalert.js')); ?>"></script>
    <script>
        $(document).ready(function () {

            <?php if(session()->has('message')): ?>
            swal({
                title: 'Message',
                text: "<?php echo e(session()->get('message')); ?>",
                type: 'info',
                confirmButtonText: 'Ok'
            });
            <?php endif; ?>

            $(document).on('click', '.send-mail', function () {
                $('#myModal').modal('show');
                $("#upload_form").trigger("reset");
            });

            $(document).on('click', '.driver-assign', function () {
                $('#myModal2').modal('show');
            });

            $(document).on('click', '.status', function () {
                $('#myModal3').modal('show');
            });

            $('#upload_form').on('submit', function () {
                event.preventDefault();
                let form = new FormData(this);
                $('.send-button').button('loading');

                $.ajax({
                    url: "<?php echo e(route('AdminSandMail')); ?>",
                    method: "POST",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form,
                    dataType: 'json',
                    error: function (data) {
                        if (data.status === 422) {
                            var errors = $.parseJSON(data.responseText);
                            let allData = '', mainData = '';
                            $.each(errors, function (key, value) {
                                if ($.isPlainObject(value)) {
                                    $.each(value, function (key, value) {
                                        allData += value + "<br/>";
                                    });
                                } else {
                                    mainData += value + "<br/>";
                                }
                            });
                            $('.send-button').button('reset');
                            swal({
                                title: mainData,
                                text: allData,
                                type: 'error',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    },
                    success: function (data) {
                        if (data == 1) {
                            $('.send-button').button('reset');
                            $('#myModal').modal('hide');
                            swal({
                                title: "Congratulation",
                                text: "Your message send to the shipper",
                                type: 'success',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    }
                });
            });

            $('#upload_form2').on('submit', function () {
                event.preventDefault();
                let form = new FormData(this);
                $('.send-button').button('loading');
                $.ajax({
                    url: "<?php echo e(route('AdminShipmentDriver')); ?>",
                    method: "POST",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form,
                    dataType: 'json',
                    error: function (data) {
                        if (data.status === 422) {
                            var errors = $.parseJSON(data.responseText);
                            let allData = '', mainData = '';
                            $.each(errors, function (key, value) {
                                if ($.isPlainObject(value)) {
                                    $.each(value, function (key, value) {
                                        allData += value + "<br/>";
                                    });
                                } else {
                                    mainData += value + "<br/>";
                                }
                            });
                            $('.send-button').button('reset');
                            swal({
                                title: mainData,
                                text: allData,
                                type: 'error',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    },
                    success: function (data) {
                        if (data == 1) {
                            $('.send-button').button('reset');
                            $('#myModal2').modal('hide');
                            swal({
                                title: "Congratulation",
                                text: "Successfully assign driver",
                                type: 'success',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    }
                });
            });

            $('#upload_form3').on('submit', function () {
                event.preventDefault();
                let form = new FormData(this);
                $('.send-button').button('loading');
                $.ajax({
                    url: "<?php echo e(route('AdminShipmentStatus')); ?>",
                    method: "POST",
                    cache: false,
                    contentType: false,
                    processData: false,
                    data: form,
                    dataType: 'json',
                    error: function (data) {
                        if (data.status === 422) {
                            var errors = $.parseJSON(data.responseText);
                            let allData = '', mainData = '';
                            $.each(errors, function (key, value) {
                                if ($.isPlainObject(value)) {
                                    $.each(value, function (key, value) {
                                        allData += value + "<br/>";
                                    });
                                } else {
                                    mainData += value + "<br/>";
                                }
                            });
                            $('.send-button').button('reset');
                            swal({
                                title: mainData,
                                text: allData,
                                type: 'error',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    },
                    success: function (data) {
                        if (data == 1) {
                            $('.send-button').button('reset');
                            $('#myModal2').modal('hide');
                            swal({
                                title: "Congratulation",
                                text: "Shipment status update",
                                type: 'success',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        } else if (data.error) {
                            $('.send-button').button('reset');
                            swal({
                                title: "Error",
                                text: data.error,
                                type: 'warning',
                                html: true,
                                confirmButtonText: 'Ok'
                            })
                        }
                    }
                });
            });

        });

        $('#myDatepicker4').datetimepicker({
            ignoreReadonly: true,
            allowInputToggle: true,
            defaultDate: new Date()
        });
    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/shipment/shipment_view.blade.php ENDPATH**/ ?>