<?php $__env->startSection('content'); ?>

    <style>
        #previewImage {
            width: 100px;
            height: 100px;
            border: 1px dotted gray;
            text-align: center;
            cursor: pointer;
        }
    </style>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Admin country manage</h3>
                </div>

                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#myModal">
                            Add New Zone country
                        </button>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <?php if(isset($oneData)): ?>
                    <div class="x_panel">
                        <div class="x_content">
                            <form class="form-horizontal form-label-left" novalidate=""
                                  action="<?php echo e(route('AdminCountryManageUpdate')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input name="id" value="<?php echo e($oneData); ?>" type="hidden">
                                <span class="section">World Zone Country Update</span>

                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">World zone
                                        name</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="name" class="form-control col-md-7 col-xs-12"
                                              value="<?php echo e(get_zone_name_by_id($oneData)->name); ?>" type="text" readonly>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">World zone
                                        name</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <select class="select2_single" name="country[]" multiple="multiple">
                                            <option></option>
                                            <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(!country_has_zone($earths['code'],$oneData)): ?>
                                                    <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($earths['code']); ?>" selected><?php echo e($earths['name']); ?></option>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo e(route('SliderManage')); ?>" type="reset" class="btn btn-primary">
                                            Cancel
                                        </a>
                                        <button id="send" type="submit" class="btn btn-success">Update</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>

                <div class="col-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <table class="table table-bordered bulk_action">
                                <thead>
                                <tr class="bg-dark">
                                    <th>#</th>
                                    <th>Name</th>
                                    <th>Country</th>
                                    <th>Action</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <tr>
                                        <th scope="row"><?php echo e($datas->world_zone_id); ?></th>
                                        <td><?php echo e(get_zone_name_by_id($datas->world_zone_id)->name); ?></td>
                                        <td>
                                            <?php $__currentLoopData = get_country_by_zone($datas->world_zone_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo e(get_country_name_by_code($country->country)->name); ?>,
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </td>
                                        <td>
                                            <a href="<?php echo e(route('AdminCountryManage',$datas->world_zone_id)); ?>" style="margin: 0 2px"
                                               data-toggle="tooltip" class="btn btn-success"
                                               data-placement="top" title=""
                                               data-original-title="Edit"><i
                                                        class="fa fa-edit"></i> Edit</a>
                                            <a href="<?php echo e(route('AdminCountryManageDelete','delete='.$datas->world_zone_id)); ?>"
                                               style="margin: 0 2px" data-toggle="tooltip"
                                               data-placement="top" title=""
                                               data-original-title="Delete" class="btn btn-danger delete"><i
                                                        class="fa fa-trash"></i> Delete</a>
                                        </td>
                                    </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>

    <!-- Modal -->
    <div id="myModal" class="modal fade" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Add World Zone Country</h4>
                </div>
                <form method="post" action="<?php echo e(route('AdminCountryManageAdd')); ?>">
                    <div class="modal-body">

                        <div class="form-horizontal form-label-left">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-group">
                                <select class="form-control" name="zone_id">
                                    <option value="">Choose option</option>
                                    <?php $__currentLoopData = $zone; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zones): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!get_country_by_zone($zones->id)): ?>
                                            <option value="<?php echo e($zones->id); ?>"><?php echo e($zones->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <select class="select2_single" name="country[]" multiple="multiple">
                                    <option></option>
                                    <?php $__currentLoopData = $earth; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $earths): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(!country_has_zone($earths['code'])): ?>
                                            <option value="<?php echo e($earths['code']); ?>"><?php echo e($earths['name']); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </form>

            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/admin/quotation/country_manage.blade.php ENDPATH**/ ?>