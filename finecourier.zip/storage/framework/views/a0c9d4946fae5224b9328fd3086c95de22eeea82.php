<!-- footer content -->
<footer>
    <div class="pull-right">
        <?php echo e(basic_information()->footer_text); ?> <a
                href="<?php echo e(basic_information()->website_link); ?>"><?php echo e(basic_information()->company_name); ?></a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content --><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/inc/footer.blade.php ENDPATH**/ ?>