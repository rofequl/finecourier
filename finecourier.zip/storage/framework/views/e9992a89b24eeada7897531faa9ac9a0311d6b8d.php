<?php $__env->startSection('pageTitle','Shipping List'); ?>
<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>All Reject shipping information</h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <p>Simple table with shipping request any people</p>

                            <!-- start project list -->
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered projects">
                                    <thead>
                                    <tr>
                                        <th class="text-center" style="width: 1%">#</th>
                                        <th class="text-center">Tracking Code</th>
                                        <th class="text-center">Date</th>
                                        <th class="text-center">Name</th>
                                        <th class="text-center">From</th>
                                        <th class="text-center">To</th>
                                        <th class="text-center">Shipping type</th>
                                        <th class="text-center">Shipping content</th>
                                        <th class="text-center">Status</th>
                                        <th class="text-center">Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $no=1; ?>
                                    <?php $__currentLoopData = $shipment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="text-center">
                                            <td><?php echo e($no); ?></td>
                                            <?php $no++; ?>
                                            <td>
                                                <?php echo DNS1D::getBarcodeHTML($shipments->tracking_code, "EAN13",1,23); ?>

                                                <p style="font-size: 15px;color: black;">
                                                    *<?php echo e($shipments->tracking_code); ?>*</p>
                                            </td>
                                            <td>
                                                <?php echo e($shipments->created_at->format('d M, Y')); ?>

                                            </td>
                                            <td>
                                                <a title="Header" data-toggle="popover" data-trigger="hover"
                                                   data-content="Some content">
                                                    <?php echo e(get_user_by_id($shipments->user_id)->first_name); ?>

                                                    <?php echo e(get_user_by_id($shipments->user_id)->last_name); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($shipments->address_one); ?></td>
                                            <td><?php echo e($shipments->address_two); ?></td>
                                            <td>
                                                <?php if($shipments->shipment == 1): ?>
                                                    International
                                                <?php else: ?>
                                                    Domestic
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($shipments->shipping_type); ?>

                                            </td>
                                            <td>

                                                <?php if($shipments->block == 1): ?>
                                                    <span class="label label-danger">Reject</span>
                                                <?php else: ?>
                                                    <span class="label label-success">
                                                    <?php echo e($shipments->status==1?'Confirm Shipment':''); ?>

                                                        <?php echo e($shipments->status==2?'Picked':''); ?>

                                                        <?php echo e($shipments->status==3?'Container':''); ?>

                                                        <?php echo e($shipments->status==4?'Shipped':''); ?>

                                                        <?php echo e($shipments->status==5?'Delivered':''); ?>

                                                        <?php echo e($shipments->status==6?'Block':''); ?>

                                                </span><br>
                                                    <?php if($shipments->status != 1): ?>
                                                        <?php echo e(get_shipment_status($shipments->tracking_code, $shipments->status)->time); ?>

                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('AdminShipmentView','data='.base64_encode($shipments->id))); ?>"
                                                   class="btn btn-success">View</a>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php echo $shipment->render(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/manage_shipment/reject.blade.php ENDPATH**/ ?>