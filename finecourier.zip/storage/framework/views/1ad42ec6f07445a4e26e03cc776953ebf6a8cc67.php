<?php $__env->startSection('pageTitle','Booking Request list'); ?>
<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>All Booking request information</h3>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="x_panel">
                        <div class="x_content">

                            <p>Simple table with booking request any people</p>

                            <!-- start project list -->
                            <div class="table-responsive">
                                <table class="table table-striped projects">
                                    <thead>
                                    <tr>
                                        <th style="width: 1%">#</th>
                                        <th>Name</th>
                                        <th>Date</th>
                                        <th>Tracking Code</th>
                                        <th>Shipping type</th>
                                        <th>Shipping content</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $shipping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="tr">
                                            <td>#</td>
                                            <td>
                                                <a><?php echo e($shipment->shipper_name); ?></a>
                                                <br>
                                                <a><?php echo e(get_country_name_by_code($shipment->from_country)->name); ?></a>
                                            </td>
                                            <td>
                                                <?php if($shipment->booking_type == 1): ?>
                                                    <?php echo e($shipment->created_at->format('d-M-Y')); ?>

                                                <?php else: ?>
                                                    Pickup: <?php echo e($shipment->pickup_date); ?> <br>
                                                    Delivery: <?php echo e($shipment->pickup_delivery); ?>

                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($shipment->tracking_code != ''): ?>
                                                    <?php echo DNS1D::getBarcodeHTML($shipment->tracking_code, "EAN13",1,23); ?>

                                                    <p style="font-size: 15px;color: black;">
                                                        *<?php echo e($shipment->tracking_code); ?>*</p>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($shipment->booking_type == 1): ?>
                                                    International
                                                <?php else: ?>
                                                    Domestic
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($shipment->shipping_type); ?>

                                            </td>
                                            <td>
                                                <?php if($shipment->status == 0): ?>
                                                    <span class="label label-success">Request</span>
                                                <?php elseif($shipment->status == 1): ?>
                                                    <span class="label label-success">Ready For A Pickup</span>
                                                <?php else: ?>
                                                    <span class="label label-success">Block</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('AdminBookingRequestView','data='.base64_encode($shipment->id))); ?>"
                                                   class="btn btn-success">View</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php echo $shipping->render(); ?>


                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Nayem\finecourier\resources\views/admin/shipment/booking_shipment.blade.php ENDPATH**/ ?>