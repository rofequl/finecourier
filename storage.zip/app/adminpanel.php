<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class adminpanel extends Model
{
    //
}
