<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class slider_manage extends Model
{
    //
}
