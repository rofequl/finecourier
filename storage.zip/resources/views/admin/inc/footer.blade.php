<!-- footer content -->
<footer>
    <div class="pull-right">
        {{basic_information()->footer_text}} <a
                href="{{basic_information()->website_link}}">{{basic_information()->company_name}}</a>
    </div>
    <div class="clearfix"></div>
</footer>
<!-- /footer content -->