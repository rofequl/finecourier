<!DOCTYPE html>
<html lang="en">


<head>
    <meta charset="UTF-8">

    <!-- viewport meta -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>"/>
    <title>Fine -</title>

    <!-- owl carousel css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/owl.carousel.css')); ?>"/>


    <!-- font icofont -->
    <link rel="stylesheet" href="<?php echo e(asset('css/font-awesome.min.css')); ?>"/>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700|Montserrat:300,400,400i,700,900" rel="stylesheet">

    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>"/>

    <!-- animte css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/animate.css')); ?>"/>

    <!-- camera css goes here -->
    <link rel="stylesheet" href="<?php echo e(asset('css/camera.css')); ?>">

    <!-- venobox css goes here -->
    <link rel="stylesheet" href="<?php echo e(asset('css/venobox.css')); ?>">

    <!-- style css -->
    <link rel="stylesheet" href="<?php echo e(asset('style.css')); ?>"/>

    <!-- responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('css/responsive.css')); ?>">

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
</head>
<body class="
<?php if(Route::is('home')): ?>
        home1
<?php elseif(Route::is('about_us')): ?>
        about_us_page
<?php elseif(Route::is('service')): ?>
        service_page
<?php elseif(Route::is('news')): ?>
        news_page
<?php elseif(Route::is('contact')): ?>
        request_quote
<?php elseif(Route::is('track_trace')): ?>
        track_trace
<?php else: ?>
        home1
<?php endif; ?>">

<!-- preloader -->
<div class="preloader-bg">
    <div class="preloader-container">
        <div class="my-preloader"><img src="<?php echo e(asset('images/favicon.png')); ?>" alt="preloader"></div>
    </div>
</div>

<?php echo $__env->make('inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--//////////////////// JS GOES HERE ////////////////-->

<!-- jquery latest version -->
<script src="<?php echo e(asset('js/jquery-1.12.3.js')); ?>"></script>

<!-- bootstrap js -->
<script src="<?php echo e(asset('js/bootstrap.min.js')); ?>"></script>

<!-- jquery easing 1.3 -->
<script src="<?php echo e(asset('js/jquery.easing1.3.js')); ?>"></script>

<!-- Owl carousel js-->
<script src="<?php echo e(asset('js/owl.carousel.min.js')); ?>"></script>

<!-- venobox js -->
<script src="<?php echo e(asset('js/venobox.min.js')); ?>"></script>

<!-- Isotope js-->
<script src="<?php echo e(asset('js/isotope.js')); ?>"></script>

<!-- Pakcery layout js-->
<script src="<?php echo e(asset('js/packery.js')); ?>"></script>

<!-- waypoint js -->
<script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>

<!-- google map js -->
<script src="http://maps.googleapis.com/maps/api/js"></script>

<!-- smoothscroll js -->
<script src="<?php echo e(asset('js/jqury.smooth-scroll.min.js')); ?>"></script>

<!-- jquery camera slider js -->
<script src="<?php echo e(asset('js/jquery.camera.min.js')); ?>"></script>
<!-- Counter up -->
<script src="<?php echo e(asset('js/jquery.counterup.js')); ?>"></script>

<!-- Waypoint -->
<script src="<?php echo e(asset('js/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/share.js')); ?>"></script>
<!-- Main js -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>

<script src="<?php echo e(asset('js/finecourier.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/layout/app.blade.php ENDPATH**/ ?>