<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('inc.slide_area', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!--================================
    START LOGIN AREA
=================================-->
    <section class="login_area reveal animated" data-delay="0.2s" data-anim="fadeInUpShort">
        <!-- container starts -->
        <div class="container">
            <!-- row starts -->
            <div class="row">
                <?php echo $__env->make('inc.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="col-sm-4 col-md-3">
                    <?php echo $__env->yieldContent('content2'); ?>
                </div>

            </div>
        </div><!-- /.row ends -->
        </div><!-- container ends -->
    </section>
    <!--================================
        END LOGIN AREA
    =================================-->





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/dashboard/main.blade.php ENDPATH**/ ?>