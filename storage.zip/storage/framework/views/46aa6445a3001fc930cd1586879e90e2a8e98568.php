<?php $__env->startSection('content2'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/dashboard/bashboard.blade.php ENDPATH**/ ?>