<?php $__env->startSection('content'); ?>

    <style>
        #previewImage {
            width: 100px;
            height: 100px;
            border: 1px dotted gray;
            text-align: center;
            cursor: pointer;
        }
    </style>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>News</h3>
                </div>

                <div class="title_right">
                    <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                        <a data-toggle="collapse" data-target=".multi-collapse"
                           aria-expanded="false" class="btn btn-primary btn-sm"
                           aria-controls="multiCollapseExample1 multiCollapseExample2"><i
                                    class="fa fa-plus"></i> Add New Slide</a>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
            <hr>
            <?php if($errors->any()): ?>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <?php echo e($error); ?>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
            <div class="row">
                <?php if(isset($oneData)): ?>
                    <div class="x_panel">
                        <div class="x_content">
                            <form class="form-horizontal form-label-left" novalidate=""
                                  action="<?php echo e(route('AdminNewsUpdate')); ?>" method="post"
                                  enctype="multipart/form-data">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="id" value="<?php echo e($oneData->id); ?>">
                                <span class="section">Add News</span>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">News
                                        Writer Name</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="name" class="form-control col-md-7 col-xs-12"
                                               data-validate-length-range="6" data-validate-words="2"
                                               name="name" value="<?php echo e($oneData->name); ?>"
                                               placeholder="News Writer" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">News
                                        Title</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="name" class="form-control col-md-7 col-xs-12"
                                               data-validate-length-range="6" data-validate-words="2"
                                               name="title"  value="<?php echo e($oneData->title); ?>"
                                               placeholder="News Title" type="text">
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name2">News
                                        Information</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                                <textarea id="textarea" name="description"
                                                          class="form-control col-md-7 col-xs-12">value="<?php echo e($oneData->description); ?>"</textarea>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12">News Tags</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <input id="tags_1" type="text" class="tags form-control" name="tag" value="<?php echo e($oneData->tag); ?>"/>
                                    </div>
                                </div>
                                <div class="item form-group">
                                    <label class="control-label col-md-3 col-sm-3 col-xs-12">News
                                        Image</label>
                                    <div class="col-md-6 col-sm-6 col-xs-12">
                                        <div onclick="chooseFile()" id="previewImage">
                                            <div class="mt-5">
                                                <i class="fa fa-cloud-upload fa-3x"></i><br>
                                                Add a News Image
                                            </div>
                                        </div>
                                        <input type="file" name="image" class="ImageUpload hidden">
                                    </div>
                                </div>
                                <div class="ln_solid"></div>
                                <div class="form-group">
                                    <div class="col-md-6 col-md-offset-3">
                                        <a href="<?php echo e(route('AdminNews')); ?>" type="reset" class="btn btn-primary">
                                            Cancel
                                        </a>
                                        <button id="send" type="submit" class="btn btn-success">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
                <div class="col">
                    <div class="collapse multi-collapse" id="multiCollapseExample1">
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_content">
                                    <form class="form-horizontal form-label-left" novalidate=""
                                          action="<?php echo e(route('AdminNewsAdd')); ?>" method="post"
                                          enctype="multipart/form-data">
                                        <?php echo e(csrf_field()); ?>

                                        <span class="section">Add News</span>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">News
                                                Writer Name</label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input id="name" class="form-control col-md-7 col-xs-12"
                                                       data-validate-length-range="6" data-validate-words="2"
                                                       name="name"
                                                       placeholder="News Writer" type="text">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name">News
                                                Title</label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input id="name" class="form-control col-md-7 col-xs-12"
                                                       data-validate-length-range="6" data-validate-words="2"
                                                       name="title"
                                                       placeholder="News Title" type="text">
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12" for="name2">News
                                                Information</label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <textarea id="textarea" name="description"
                                                          class="form-control col-md-7 col-xs-12"></textarea>
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">News Tags</label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <input id="tags_1" type="text" class="tags form-control" value="" name="tag"/>
                                            </div>
                                        </div>
                                        <div class="item form-group">
                                            <label class="control-label col-md-3 col-sm-3 col-xs-12">News
                                                Image</label>
                                            <div class="col-md-6 col-sm-6 col-xs-12">
                                                <div onclick="chooseFile()" id="previewImage">
                                                    <div class="mt-5">
                                                        <i class="fa fa-cloud-upload fa-3x"></i><br>
                                                        Add a News Image
                                                    </div>
                                                </div>
                                                <input type="file" name="image" class="ImageUpload hidden">
                                            </div>
                                        </div>
                                        <div class="ln_solid"></div>
                                        <div class="form-group">
                                            <div class="col-md-6 col-md-offset-3">
                                                <button type="reset" class="btn btn-primary" data-toggle="collapse"
                                                        data-target=".multi-collapse"
                                                        aria-expanded="false"
                                                        aria-controls="multiCollapseExample1 multiCollapseExample2">
                                                    Cancel
                                                </button>
                                                <button id="send" type="submit" class="btn btn-success">Submit</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col">
                    <div class="collapse multi-collapse show" id="multiCollapseExample2">
                        <div class="row">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="col-md-3 col-xs-12 widget widget_tally_box">
                                    <div class="x_panel fixed_height_390">
                                        <div class="pull-left">
                                            <?php if($datas->status == 0): ?>
                                                <a href="<?php echo e(route('AdminNewsStatus','show='.$datas->id)); ?>"
                                                   class="label label-default">Inactive</a>
                                            <?php else: ?>
                                                <a href="<?php echo e(route('AdminNewsStatus','hide='.$datas->id)); ?>"
                                                   class="label label-primary">Active</a>
                                            <?php endif; ?>
                                        </div>
                                        <div role="presentation" class="dropdown pull-right">
                                            <a id="drop4" href="#" data-toggle="dropdown" aria-haspopup="true"
                                               role="button"
                                               aria-expanded="false">
                                                <i class="fa fa-reorder"></i>
                                            </a>
                                            <ul id="menu6" class="dropdown-menu animated fadeInDown" role="menu">
                                                <li role="presentation"><a role="menuitem" tabindex="-1"
                                                                           href="<?php echo e(route('AdminNews',$datas->id)); ?>"><i
                                                                class="fa fa-edit"></i> Edit</a>
                                                </li>
                                                <li role="presentation"><a role="menuitem" tabindex="-1" class="delete"
                                                                           href="<?php echo e(route('AdminNewsDelete','delete='.$datas->id)); ?>"><i
                                                                class="fa fa-trash"></i> Delete</a>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="x_content">
                                            <div class="flex">
                                                <div>
                                                    <img src="<?php echo e(asset('storage/news/'.$datas->image)); ?>" alt="..."
                                                         class="img-circle profile_img img-responsive center-block">
                                                </div>
                                            </div>
                                            <br>
                                            <ul class="list-inline">
                                                <li><a href="#"><span class="fa fa-user"></span> <?php echo e($datas->name); ?></a>
                                                </li>
                                                <li><a href="#"><span class="fa fa-heart-o"></span> <?php echo e($datas->like); ?></a>
                                                </li>
                                            </ul>
                                            <h4 class=""><?php echo e($datas->title); ?></h4>
                                            <hr>
                                            <p class="text-justify"><?php echo e(str_limit($datas->description,120)); ?></p>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css" rel="stylesheet"/>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- validator -->
    <script src="<?php echo e(asset('assets/vendors/validator/validator.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.js"></script>
    <script>
        function chooseFile() {
            $(".ImageUpload").click();
        }

        $(function () {
            $(".ImageUpload").change(function () {
                let file = this.files[0];
                let imagefile = file.type;
                let match = ["image/jpeg", "image/png", "image/jpg"];
                if (!((imagefile == match[0]) || (imagefile == match[1]) || (imagefile == match[2]))) {
                    alert("only jpeg, jpg and png Images type allowed");
                    return false;
                } else {
                    $('#previewImage').html('<img src="" class="img-thumbnail h-100 mx-auto" id="previewLogo">');
                    let reader = new FileReader();
                    reader.onload = imageIsLoaded;
                    reader.readAsDataURL(this.files[0]);
                }
            });
        });

        function imageIsLoaded(e) {
            $('#previewLogo').attr('src', e.target.result);
        }

        $('.delete').click(function (e) {
            e.preventDefault(); // Prevent the href from redirecting directly
            var linkURL = $(this).attr("href");
            warnBeforeRedirect(linkURL);
        });

        function warnBeforeRedirect(linkURL) {
            swal({
                title: "Sure want to delete?",
                text: "If you click 'OK' file will be deleted",
                type: "warning",
                showCancelButton: true
            }, function () { // Redirect the user | linkURL is href url
                window.location.href = linkURL;
            });
        }
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nayem\finecourier\resources\views/admin/news.blade.php ENDPATH**/ ?>